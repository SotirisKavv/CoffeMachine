package project.hw.gui;

import java.awt.Color;

import tuc.ece.cs201.vm.hw.device.Device;
import tuc.ece.cs201.vm.hw.device.DeviceType;
import tuc.ece.cs201.vm.hw.device.FlowContainerDevice;

public class GraphicFlowContainer extends GraphicContainer implements FlowContainerDevice{

	int streamRate;
	public GraphicFlowContainer(String name, int capacity, int stream_rate, int x, int y, int width, int height, int border,
			 Color color) {
		super(name, capacity, x, y, width, height, border, color);
		streamRate=stream_rate;
	}

	public void streamOut(Device toConnectedDevice) {
		decreaseContent(this.streamRate());
	}

	public int streamRate() {
		return 5;
	}
	
	@Override
	public DeviceType getType() {
		return DeviceType.FlowContainer;
	}

}
