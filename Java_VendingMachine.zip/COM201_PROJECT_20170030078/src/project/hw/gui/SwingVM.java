package project.hw.gui;

import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.swing.JFrame;

import tuc.ece.cs201.vm.hw.HardwareMachine;
import tuc.ece.cs201.vm.hw.device.Device;


public class SwingVM extends JFrame implements HardwareMachine {
	
	private static final long serialVersionUID = 1L;
	public static final String model = "SwingVM 1.0";
	ExternalDevices ext_devs;
	InternalDevices in_devs;
	private HashMap<String,Device> devices = new HashMap<String,Device>();
	
	public static final Color active_color = Color.orange;
	public static final Color operate_color = Color.red;
	public static final Color deactive_color = Color.lightGray;
	public static final Color fg_color = Color.black;
	public static final Color coffee_color = new Color(109, 97, 60);
	public static final Color sugar_color = new Color (255,255,255);
	public static final Color cinammon_color = new Color (178,77,5);
	public static final Color brown_sugar_color = new Color (193,122,94);
	public static final Color water_color = new Color (159,225,242);
	public static final Color milk_color = new Color (249,253,255);
	public static final Color light_milk_color = new Color (252,254,255);
	public static final Color hazelnut_syrup_color = new Color (221,156,15);
	public static final Color coffe_product_color = new Color (186, 131, 29);

	
    final static BasicStroke stroke = new BasicStroke(1.0f);
    final static BasicStroke dstroke = new BasicStroke(2.0f);
    final static BasicStroke wstroke = new BasicStroke(8.0f);
    final static BasicStroke bstroke = new BasicStroke(2, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND);
    
    final static float dash1[] = {5.0f};
    final static BasicStroke dashed = new BasicStroke(1.0f,BasicStroke.CAP_BUTT, BasicStroke.JOIN_MITER, 10.0f, dash1, 0.0f);
		
	private static SwingVM vm;
	
	
	private SwingVM() {
		super(model);
		this.setVisible(true);
		this.setResizable(false);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
	}
	
	private void initDevices() {
		ext_devs = new ExternalDevices();
		in_devs = new InternalDevices();
		
		Container pcont = this.getContentPane();
		pcont.add(ext_devs, BorderLayout.LINE_START);
		pcont.add(in_devs, BorderLayout.LINE_END);
		pack();
	}
	
	public static SwingVM getInstance() {
		if (vm==null) {
			vm = new SwingVM();
			vm.initDevices();
		}
		return vm;
	}
	
	public static void sleep(int secs) {
		try {
			Thread.sleep(secs*1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	public void refresh() {
		this.repaint();
	}
	
	public void addDevice(String name,Device mod) {
		devices.put(name, mod);
	}
	
	public Device getDevice(String name) {
		return devices.get(name);
	}

	@Override
	public String getModel() {
		return model;
	}

	@Override
	public List<Device> listDevices() {
		return  new ArrayList<>(devices.values());
	}
	
	public static Color blend(Color c0, Color c1) {
	    double totalAlpha = c0.getAlpha() + c1.getAlpha();
	    double weight0 = c0.getAlpha() / totalAlpha;
	    double weight1 = c1.getAlpha() / totalAlpha;

	    double r = weight0 * c0.getRed() + weight1 * c1.getRed();
	    double g = weight0 * c0.getGreen() + weight1 * c1.getGreen();
	    double b = weight0 * c0.getBlue() + weight1 * c1.getBlue();
	    double a = Math.max(c0.getAlpha(), c1.getAlpha());

	    return new Color((int) r, (int) g, (int) b, (int) a);
	}

}
