package project.hw.gui;

import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JPanel;

public class ExternalDevices extends JPanel {
	
	
	private static final long serialVersionUID = -5657496740767515282L;
	
	SwingNumPad numpad;
	SwingCoinAcceptor coin_acceptor;
	SwingDisplayPanel display_panel;
	SwingChangeCase change_case;
	
	public ExternalDevices() {
		this.setBackground(Color.DARK_GRAY);
		this.setPreferredSize(new Dimension(250, 700));
		coin_acceptor = new SwingCoinAcceptor();
		numpad = new SwingNumPad();
		display_panel = new SwingDisplayPanel();
		change_case = new SwingChangeCase();
		this.add(coin_acceptor);
		SwingVM.getInstance().addDevice("COIN_ACCEPTOR", coin_acceptor);
		this.add(numpad);
		SwingVM.getInstance().addDevice("NUMPAD", numpad);
		this.add(display_panel);
		SwingVM.getInstance().addDevice("DISPLAY_PANEL", display_panel);
		this.add(change_case);
		SwingVM.getInstance().addDevice("CHANGE_CASE", change_case);
	}

}
