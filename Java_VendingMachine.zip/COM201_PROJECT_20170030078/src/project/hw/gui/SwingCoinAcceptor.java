package project.hw.gui;

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemListener;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;

import tuc.ece.cs201.vm.hw.device.CoinAcceptorDevice;
import tuc.ece.cs201.vm.hw.device.Device;

public class SwingCoinAcceptor extends JPanel implements ActionListener, CoinAcceptorDevice{
	
	
	private static final long serialVersionUID = 6531469149415719679L;
	
	JLabel jlabel;
	JComboBox<String> jcoins;
	
	public static String[] accetpedCoins = {"1", "2", "5", "10", "20", "50", "100", "200"};
	int keyPressed = -1;
	boolean active;
	
	public SwingCoinAcceptor() {
		jlabel = new JLabel("Coin Acceptor");
		jlabel.setAlignmentX(RIGHT_ALIGNMENT);
		jcoins = new JComboBox<String>(accetpedCoins);
		jcoins.setAlignmentX(CENTER_ALIGNMENT);
		this.setLayout(new BoxLayout(this, BoxLayout.PAGE_AXIS));
		this.setPreferredSize(new Dimension(250, 75));
		this.add(jlabel);
		this.add(jcoins);
		this.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
		jcoins.setEnabled(active);
		jcoins.addActionListener(this);
	}
	
	public boolean isLocked() {
		return active;
	}

	public void lock() {
		this.setBackground(SwingVM.deactive_color);
		jcoins.setEnabled(false);
		active = false;
	}

	public void unLock() {
		this.setBackground(SwingVM.active_color);
		jcoins.setEnabled(true);
		active = true;
	}

	@Override
	public void connect(Device device) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void disconnect(Device device) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void disconnectAll() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Device> listConnectedDevices() {
		// TODO Auto-generated method stub
		return null;
	}

	public synchronized int acceptCoin(int subTotal) {
		keyPressed=-1;
		try {
			wait();
		} catch (InterruptedException e) {			
			e.printStackTrace();
		}
		return keyPressed;
	}
	
	public synchronized void actionPerformed(ActionEvent ev) {
		try {
			keyPressed = Integer.parseInt((String)((JComboBox<?>)ev.getSource()).getSelectedItem());
		} 
		catch(NumberFormatException ex) {
			keyPressed = -1;
		}
		notify();
	}
	
	public void addComboObserver(ItemListener listener) {
		jcoins.addItemListener(listener);
	}

}
