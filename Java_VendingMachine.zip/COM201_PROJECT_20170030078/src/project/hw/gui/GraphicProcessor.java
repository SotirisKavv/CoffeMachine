package project.hw.gui;

import java.awt.Color;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import java.awt.geom.RoundRectangle2D;
import java.util.List;

import tuc.ece.cs201.vm.hw.device.Device;
import tuc.ece.cs201.vm.hw.device.ProcessorDevice;

public class GraphicProcessor extends GraphicDevice implements ProcessorDevice{
	
	Color color;
	int capacity;
	int currentQuantity;
	boolean isOpen;
	boolean isOperating;
	int streamRate;
	String label;
	

	public GraphicProcessor(String name,int capacity, int streamRate, String label, int x, int y, int width, int height, int padding, Color color) {
		super(name, x, y, width, height, padding);
		this.color=color;
		this.capacity=capacity;
		this.currentQuantity=0;
		this.streamRate=streamRate;
		this.label=label;
	}
	
	public void streamOut(Device arg0) {
		decreaseContent(this.streamRate());
	}

	public int streamRate() {
		return this.streamRate;
	}

	public void close() {
		deActivate();
	}

	public int getCapacity() {
		return this.capacity;
	}

	public boolean isOpen() {
		return active;
	}

	public void open() {
		activate();
	}

	@Override
	public void connect(Device device) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void disconnect(Device device) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void disconnectAll() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Device> listConnectedDevices() {
		// TODO Auto-generated method stub
		return null;
	}

	public String getProcessingLabel() {
		return label;
	}

	public void operateStart() {
		this.isOperating=true;
		SwingVM.getInstance().refresh();
	}

	public void operateStop() {
		this.isOperating=false;
		SwingVM.getInstance().refresh();
	}

	public void streamIn() {
		increaseContent(this.streamRate());
	}

	public void draw(Graphics g) {
		Graphics2D g2 = (Graphics2D) g;
		FontMetrics fontMetrics = pickFont(g2, name,width);
        int rectWidth = width - 2*padding;
        int labely = height -fontMetrics.getDescent() - 3;
        int rectHeight = labely - fontMetrics.getMaxAscent() - padding;
 
        g2.setStroke(SwingVM.bstroke);
        if (active) {
        	g2.setPaint(SwingVM.active_color);
        	g2.setStroke(SwingVM.wstroke);
        }
        g2.draw(new Rectangle2D.Double(x+padding, y+padding, rectWidth, rectHeight));
        g2.setPaint(color);
        if (isOperating) {
        	g2.setPaint(SwingVM.operate_color);
        }
        double fillPercent = (double)this.currentQuantity / (double)this.capacity;
        g2.fill(new RoundRectangle2D.Double(x+padding+5, y+padding+(rectHeight*(1-fillPercent))+5, rectWidth-10, rectHeight*fillPercent-10, 10, 10));
        
        g2.setPaint(SwingVM.fg_color);
        g2.setStroke(SwingVM.stroke);

        g2.drawString(name, x + padding, y+labely);
	
	}
	
	public void decreaseContent(int size) {
		this.currentQuantity -= size;
		if (this.currentQuantity<0) this.currentQuantity = 0;
		SwingVM.getInstance().refresh();
	}
	
	public void increaseContent(int size) {
		this.currentQuantity += size;
		if (this.currentQuantity>this.capacity) this.currentQuantity=this.capacity;
		SwingVM.getInstance().refresh();
	}
}
