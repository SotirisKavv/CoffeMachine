package project.hw.gui;

import java.awt.Color;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Line2D;
import java.awt.geom.RoundRectangle2D;
import java.util.ArrayList;
import java.util.List;

import tuc.ece.cs201.vm.hw.device.ContainerDevice;
import tuc.ece.cs201.vm.hw.device.Device;
import tuc.ece.cs201.vm.hw.device.DeviceType;
import tuc.ece.cs201.vm.hw.device.DispenserDevice;

public class GraphicDispenser<T extends GraphicContainer> extends GraphicDevice implements DispenserDevice<ContainerDevice> {
	
	List<T> containers;
	Color color;
	
	public GraphicDispenser(String name, int x, int y, int width, int height, int padding, Color color) {
		super(name, x, y, width, height, padding);
		this.color = color;
		containers = new ArrayList<>(); 
	}

	@Override
	public void connect(Device device) {
		// TODO Auto-generated method stub
	}

	@Override
	public void disconnect(Device device) {
		// TODO Auto-generated method stub
	}

	@Override
	public void disconnectAll() {
		// TODO Auto-generated method stub
		
	}

	
	public DeviceType getType() {
		return null;
	}

	@Override
	public List<Device> listConnectedDevices() {
		// TODO Auto-generated method stub
		return null;
	}

	public void addContainer(ContainerDevice containerDevice) {
		this.containers.add((T)containerDevice);
	}

	public List<ContainerDevice> listContainers() {
		return (List<ContainerDevice>) this.containers;
	}

	public void prepareContainer(ContainerDevice containerDevice) {
		this.connect(containerDevice);
		containerDevice.connect(this);
	}

	public void removeContainer(String name) {
		for(ContainerDevice gc : this.listContainers()) {
			if (gc.getName().equalsIgnoreCase(name))
				this.containers.remove(gc);
		}
		
	}

	public void draw(Graphics g) {
		Graphics2D g2 = (Graphics2D) g;
		FontMetrics fontMetrics = pickFont(g2, name,width);
        int rectWidth = width - 2*padding;
        int labely = height -fontMetrics.getDescent() - 3;
        int rectHeight = labely - fontMetrics.getMaxAscent() - padding;
 
        g2.setStroke(SwingVM.bstroke);
        g2.draw(new RoundRectangle2D.Double(x+padding, y+padding, rectWidth, rectHeight, 10, 10));
        g2.setPaint(color);
        
        g2.setStroke(SwingVM.stroke);
        for (GraphicContainer c : this.containers) {
        	c.draw(g2);
        	if (c.listConnectedDevices()!=null) {
        		g2.setColor(Color.red);
        		g2.draw(new Line2D.Double(x+rectWidth/2, rectHeight, c.x+(c.width-2*c.padding)/2, c.y+c.rectHeight));
        	}
        }
        
        g2.setPaint(SwingVM.fg_color);
        g2.setStroke(SwingVM.stroke);

        g2.drawString(name, x + padding, y+labely);
		
	}

}
