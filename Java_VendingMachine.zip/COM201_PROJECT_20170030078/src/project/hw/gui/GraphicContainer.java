
package project.hw.gui;

import java.awt.Color;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import java.awt.geom.RoundRectangle2D;
import java.util.List;

import tuc.ece.cs201.vm.hw.device.ContainerDevice;
import tuc.ece.cs201.vm.hw.device.Device;

public abstract class GraphicContainer extends GraphicDevice implements ContainerDevice {
	Color color;
	int capacity;
	int currentQuantity;
	boolean isOpen;
	int rectHeight;

	public GraphicContainer(String name, int capacity, int x, int y, int width, int height, int border,Color color) {
		super(name, x, y, width, height, border);
		
		this.color = color;
		this.capacity = capacity;
		this.currentQuantity = capacity;
		
	}

	
	public void setName(String name) {
		this.name = name;
	}
		
	public void draw(Graphics g) {
		Graphics2D g2 = (Graphics2D) g;
		FontMetrics fontMetrics = pickFont(g2, name,width);
        int rectWidth = width - 2*padding;
        int labely = height -fontMetrics.getDescent() - 3;
        int rectHeight = labely - fontMetrics.getMaxAscent() - padding;
        this.rectHeight=rectHeight;
 
        if (active) {
        	g2.setPaint(SwingVM.active_color);
        	g2.setStroke(SwingVM.wstroke);
        }
        
        g2.draw(new Rectangle2D.Double(x+padding, y+padding, rectWidth, rectHeight));
        g2.setPaint(color);
        double fillPercent = (double)this.currentQuantity / (double)this.capacity;
        g2.fill(new RoundRectangle2D.Double(x+padding+5, y+padding+(rectHeight*(1-fillPercent))+5, rectWidth-10, rectHeight*fillPercent-10, 10, 10));
        
        g2.setPaint(SwingVM.fg_color);
        g2.setStroke(SwingVM.stroke);

        g2.drawString(name, x + padding, y+labely);
	}


	public void decreaseContent(int size) {
		this.currentQuantity -= size;
		if (this.currentQuantity<0) this.currentQuantity = 0;
		SwingVM.getInstance().refresh();
	}
	
	public void increaseContent(int size) {
		this.currentQuantity += size;
		if (this.currentQuantity>this.capacity) this.currentQuantity=this.capacity;
		SwingVM.getInstance().refresh();
	}


	@Override
	public void connect(Device arg0) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void disconnect(Device arg0) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void disconnectAll() {
		// TODO Auto-generated method stub
		
	}


	@Override
	public List<Device> listConnectedDevices() {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public void close() {
		deActivate();
	}
	

	@Override
	public boolean isOpen() {
		return active;
	}


	@Override
	public void open() {
		activate();
	}


	@Override
	public int getCapacity() {
		return capacity;
	}



}