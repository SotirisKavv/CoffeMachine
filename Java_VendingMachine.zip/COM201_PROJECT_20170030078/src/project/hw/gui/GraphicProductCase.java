package project.hw.gui;

import java.awt.Color;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Polygon;
import java.awt.geom.RoundRectangle2D;
import java.util.List;

import tuc.ece.cs201.vm.hw.device.Device;
import tuc.ece.cs201.vm.hw.device.ProductCaseDevice;

public class GraphicProductCase extends GraphicDevice implements ProductCaseDevice{
	
	Color color;
	int currentQuantity;
	int capacity;
	boolean loadedMaterial, loadedIngredient;
	
	public GraphicProductCase(String name, int capacity, int x, int y, int width, int height, int padding, Color color) {
		super(name, x, y, width, height, padding);
		this.color = color;
		this.capacity = capacity;
		this.currentQuantity = 0;
		this.loadedMaterial = false;
		this.loadedIngredient = true;
	}

	public boolean isLocked() {
		return active;
	}

	public void lock() {
		deActivate();
	}

	public void unLock() {
		activate();
	}

	public void connect(Device device) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void disconnect(Device device) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void disconnectAll() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Device> listConnectedDevices() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void loadIngredient(String ingredientType) {
		this.loadedIngredient=true;
		increaseContent(3);
	}

	@Override
	public void putMaterial(String materialType) {
		this.loadedMaterial=true;
	}

	@Override
	public void draw(Graphics g) {
		Graphics2D g2 = (Graphics2D) g;
		FontMetrics fontMetrics = pickFont(g2, name,width);
        int rectWidth = width - 2*padding;
        int labely = height -fontMetrics.getDescent() - 3;
        int rectHeight = labely - fontMetrics.getMaxAscent() - padding;
 
        g2.setStroke(SwingVM.bstroke);
        if (active) {
        	g2.setPaint(SwingVM.active_color);
        	g2.setStroke(SwingVM.wstroke);
        }
        g2.draw(new RoundRectangle2D.Double(x+padding, y+padding, rectWidth, rectHeight, 10, 10));
        if (loadedMaterial) {
        	g2.setPaint(Color.black);
        	g2.setStroke(SwingVM.bstroke);
        	int[] xPoints = {x+(rectWidth/2)-3, x+rectWidth-3, x+rectWidth-18, x+(rectWidth/2)+12};
        	int[] yPoints = {(int) (y+rectHeight*0.4), (int) (y+rectHeight*0.4), y+rectHeight, y+rectHeight};
        	g2.drawPolygon(xPoints, yPoints, 4);
        }
        
        if (loadedIngredient) {
        	g2.setPaint(color);
	        double fillPercent = (double)this.currentQuantity / (double)this.capacity;
	        int[] fillX = {(int) (x+(rectWidth/2)+12-(15*fillPercent)), (int) (x+rectWidth-18+(15*fillPercent)), x+rectWidth-18, x+(rectWidth/2)+12};
	        int[] fillY = {(int) (y+rectHeight*(1-fillPercent)), (int) (y+rectHeight*(1-fillPercent)), y+rectHeight, y+rectHeight}; 
	        g2.fill(new Polygon(fillX, fillY, 4));
	        
        }    
        g2.setPaint(SwingVM.fg_color);
        g2.setStroke(SwingVM.stroke);

        g2.drawString(name, x + padding, y+labely);
		
	}
	
	public void getProduct() {
		this.loadedIngredient = false;
		this.loadedMaterial = false;
		this.currentQuantity = 0;
		SwingVM.getInstance().refresh();
	}
	
	public void increaseContent(int size) {
		this.currentQuantity += size;
		if (this.currentQuantity>this.capacity) this.currentQuantity=this.capacity;
		SwingVM.getInstance().refresh();
	}

}
