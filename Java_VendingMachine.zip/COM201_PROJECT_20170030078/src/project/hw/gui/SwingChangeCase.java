package project.hw.gui;

import java.awt.Dimension;
import java.awt.Font;

import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.util.List;

import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;

import tuc.ece.cs201.vm.hw.device.ChangeCaseDevice;
import tuc.ece.cs201.vm.hw.device.Device;

public class SwingChangeCase extends JPanel implements ChangeCaseDevice, FocusListener{
	
	private static final long serialVersionUID = -7618615573987268681L;
	
	JLabel label;
	JTextArea changeCase;
	boolean active;
	
	public SwingChangeCase() {
		label = new JLabel("Change Case");
		label.setAlignmentX(RIGHT_ALIGNMENT);
		changeCase = new JTextArea("");
		changeCase.setAlignmentX(CENTER_ALIGNMENT);
		this.setLayout(new BoxLayout(this, BoxLayout.PAGE_AXIS));
		this.add(label);
		this.add(changeCase);
		changeCase.setEditable(false);
		changeCase.setLineWrap(true);
		changeCase.setBackground(SwingVM.deactive_color);
		changeCase.setFont(new Font("Sherif", Font.PLAIN, 16));
		this.setPreferredSize(new Dimension(250, 50));
		changeCase.addFocusListener(this);
	}
	
	
	public boolean isLocked() {
		return active;
	}

	public void lock() {
		active = false;
		changeCase.setBackground(SwingVM.deactive_color);
		this.setBackground(SwingVM.deactive_color);
		changeCase.setEnabled(false);
	}

	public void unLock() {
		active = true;
		changeCase.setBackground(SwingVM.active_color);
		this.setBackground(SwingVM.active_color);
		changeCase.setEnabled(true);		
	}

	@Override
	public void connect(Device arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void disconnect(Device arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void disconnectAll() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Device> listConnectedDevices() {
		// TODO Auto-generated method stub
		return null;
	}

	public void giveChange(int coin) {
		changeCase.append(""+coin);		
	}

	public synchronized void removeChange() {
		try {
			wait();
		} catch (InterruptedException e) {			
			e.printStackTrace();
		}
	}

	public synchronized void focusGained(FocusEvent ev) {
		if(ev.getSource()==changeCase)
			changeCase.setText("");
		notify();
	}


	public void focusLost(FocusEvent arg0) {
		
	}


	

}
