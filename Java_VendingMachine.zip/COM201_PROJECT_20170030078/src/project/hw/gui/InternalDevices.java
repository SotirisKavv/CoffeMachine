package project.hw.gui;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;

import javax.swing.JPanel;

public class InternalDevices extends JPanel {

	private static final long serialVersionUID = 8364364209282259809L;
	
	GraphicContainer cont1, cont2, cont3, cont4, cont5, cont6, cont7, cont8, cont9, cont10;
	GraphicDispenser<?> pow, liq, cup;
	GraphicProcessor boiler, mixer, cooler, buffer;
	GraphicProductCase pcase;
	
	int gridWidth;
    int gridHeight;
	
	public InternalDevices() {
		Dimension d = new Dimension(900, 700);
		this.setPreferredSize(d);
		
        gridWidth = d.width / 9;
        gridHeight = d.height / 5;
        
        pow = new GraphicDispenser<GraphicDosingContainer>("POWDERS", 0, 0, 4*gridWidth, gridHeight+17, 3, Color.black);
        SwingVM.getInstance().addDevice("POWDERS", pow);
        
		cont1 = new GraphicDosingContainer("COFFEE",200,5, 0, 0, gridWidth, gridHeight, 10, SwingVM.coffee_color);
		SwingVM.getInstance().addDevice("COFFEE", cont1);
		pow.addContainer(cont1);
		
		cont2 = new GraphicDosingContainer("SUGAR",200,5, gridWidth, 0, gridWidth, gridHeight, 10, SwingVM.sugar_color);
		SwingVM.getInstance().addDevice("SUGAR", cont2);
		pow.addContainer(cont2);
		
		cont3 = new GraphicDosingContainer("CINAMMON",200,5, 2*gridWidth, 0, gridWidth, gridHeight, 10, SwingVM.cinammon_color);
		SwingVM.getInstance().addDevice("CINAMMON", cont3);
		pow.addContainer(cont3);
		
		cont4 = new GraphicDosingContainer("BROWN_SUGAR", 200, 5, 3*gridWidth, 0, gridWidth, gridHeight, 10, SwingVM.brown_sugar_color); 
		SwingVM.getInstance().addDevice("BROWN_SUGAR", cont4);
		pow.addContainer(cont4);
		
		liq = new GraphicDispenser<GraphicFlowContainer>("LIQUIDS", 5*gridWidth, 0, 4*gridWidth, gridHeight+17, 3, Color.black);
        SwingVM.getInstance().addDevice("LIQUIDS", liq);
		
		cont5 = new GraphicFlowContainer("WATER",200,5, 5*gridWidth, 0, gridWidth, gridHeight, 10, SwingVM.water_color);
		SwingVM.getInstance().addDevice("WATER", cont5);
		liq.addContainer(cont5);
		
		cont6 = new GraphicFlowContainer("MILK",200,5, 6*gridWidth, 0, gridWidth, gridHeight, 10, SwingVM.milk_color);
		SwingVM.getInstance().addDevice("MILK", cont6);
		liq.addContainer(cont6);
		
		cont7 = new GraphicFlowContainer("LIGHT_MILK",200,5, 7*gridWidth, 0, gridWidth, gridHeight, 10, SwingVM.light_milk_color);
		SwingVM.getInstance().addDevice("LIGHT_MILK", cont7);
		liq.addContainer(cont7);
		
		cont8 = new GraphicFlowContainer("HN_SYRUP",200,5, 8*gridWidth, 0, gridWidth, gridHeight, 10, SwingVM.hazelnut_syrup_color);
		SwingVM.getInstance().addDevice("HN_SYRUP", cont8);
		liq.addContainer(cont8);
		
		cup = new GraphicDispenser<GraphicMaterialContainer>("CUPS", 0*gridWidth, 3*gridHeight, 2*gridWidth, 2*gridHeight, 3, Color.black);
		SwingVM.getInstance().addDevice("CUPS", cup);
		
		cont9= new GraphicMaterialContainer("SMALL_CUPS", 10, 35, 1*gridWidth, 4*gridWidth+20, gridWidth, 2*gridHeight-20, 10, null);
		SwingVM.getInstance().addDevice("SMALL_CUP", cont9);
		cup.addContainer(cont9);
		
		cont10= new GraphicMaterialContainer("BIG_CUPS", 10, 50, 0*gridWidth, 4*gridWidth+20, gridWidth, 2*gridHeight-20, 10, null);
		SwingVM.getInstance().addDevice("BIG_CUP", cont10);
		cup.addContainer(cont10);
		
		boiler = new GraphicProcessor("BOILER", 300, 5, "hot", 5*gridWidth, gridHeight+5, 2*gridWidth, gridHeight, 10, SwingVM.blend(SwingVM.sugar_color, SwingVM.water_color));
		SwingVM.getInstance().addDevice("BOILER", boiler);
		
		cooler = new GraphicProcessor("COOLER", 300, 5, "cold", 7*gridWidth, gridHeight+5, 2*gridWidth, gridHeight, 10, SwingVM.blend(SwingVM.sugar_color, SwingVM.water_color));
		SwingVM.getInstance().addDevice("COOLER", cooler);
		
		mixer = new GraphicProcessor("MIXER", 300, 5, "mixed", 3*gridWidth, 2*gridHeight, 2*gridWidth, gridHeight, 10, SwingVM.blend(SwingVM.coffee_color, SwingVM.water_color));
		SwingVM.getInstance().addDevice("MIXER", mixer);
		
		buffer = new GraphicProcessor("BUFFER", 300, 5, null, 0*gridWidth, 2*gridHeight, 2*gridWidth, gridHeight, 10, SwingVM.blend(SwingVM.sugar_color, SwingVM.hazelnut_syrup_color));
		SwingVM.getInstance().addDevice("BUFFER", buffer);
		
		pcase = new GraphicProductCase("Product Case", 300, 4*gridWidth, 3*gridHeight, 4*gridWidth, 2*gridHeight, 10, SwingVM.coffe_product_color);
		SwingVM.getInstance().addDevice("CUP_CASE", pcase);
	}
	
	
	@Override
	public void paintComponent(Graphics g) {
		// Get the subclass Graphics2D
		Graphics2D g2 = (Graphics2D)g;
		
		//Draw all Graphic Devices in Internal Devices
		pow.draw(g2);
		liq.draw(g2);
		cup.draw(g2);
		boiler.draw(g2);
		cooler.draw(g2);
		mixer.draw(g2);
		buffer.draw(g2);
		pcase.draw(g2);
		
		//  Draw the grid with dashes lines		
		/*g2.setStroke(SwingVM.dashed);
        
		for (int h = gridHeight;h<getSize().getHeight();h+=gridHeight)
			g.drawLine(0, h, (int)getSize().getWidth(), h);
		
		for (int w = gridWidth;w<getSize().getWidth();w+=gridWidth)
			g.drawLine(w,0, w,(int)getSize().getHeight());
		// -------------------------------
		
		g2.setStroke(SwingVM.stroke);*/
		
	}
}
