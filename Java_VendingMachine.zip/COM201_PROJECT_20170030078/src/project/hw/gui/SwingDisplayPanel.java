package project.hw.gui;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.util.List;

import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;

import tuc.ece.cs201.vm.hw.device.Device;
import tuc.ece.cs201.vm.hw.device.DisplayDevice;

public class SwingDisplayPanel extends JPanel implements DisplayDevice{
	
	private static final long serialVersionUID = -3345773408145165843L;
	
	JLabel label;
	JTextArea displayPanel;
	
	public SwingDisplayPanel() {
		label = new JLabel("Display Panel");
		label.setAlignmentX(RIGHT_ALIGNMENT);
		displayPanel = new JTextArea("");
		displayPanel.setAlignmentX(CENTER_ALIGNMENT);
		this.setLayout(new BoxLayout(this, BoxLayout.PAGE_AXIS));
		this.add(label);
		this.add(displayPanel);
		Dimension d = new Dimension(250, 350);
		displayPanel.setPreferredSize(d);
		displayPanel.setLineWrap(true);
		displayPanel.setEditable(false);
		displayPanel.setBackground(Color.black);
		displayPanel.setForeground(Color.white);
		displayPanel.setFont(new Font("Calibri", Font.PLAIN, 12));
	}
	
	@Override
	public void connect(Device device) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void disconnect(Device device) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void disconnectAll() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Device> listConnectedDevices() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void clear() {
		displayPanel.setText("");
		
	}

	public void displayMsg(String txt) {
		displayPanel.append(txt);
	}

}
