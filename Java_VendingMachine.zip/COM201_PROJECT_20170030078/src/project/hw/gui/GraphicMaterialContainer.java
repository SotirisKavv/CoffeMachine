package project.hw.gui;

import java.awt.Color;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;

import tuc.ece.cs201.vm.hw.device.Device;
import tuc.ece.cs201.vm.hw.device.DeviceType;
import tuc.ece.cs201.vm.hw.device.MaterialContainerDevice;

public class GraphicMaterialContainer extends GraphicContainer implements MaterialContainerDevice{

	int baseWidth;
	int cupHeight;
	
	public GraphicMaterialContainer(String name, int capacity, int baseWidth, int x, int y, int width, int height, int border,
			Color color) {
		super(name, capacity, x, y, width, height, border, color);
		this.currentQuantity=capacity;
		this.baseWidth = baseWidth;
	}

	public DeviceType getType() {
		return DeviceType.MaterialContainer;
	}

	public void releaseMaterial(Device toConnectedDevice) {
		decreaseContent(1);
	}
	
	public void draw(Graphics g) {
		Graphics2D g2 = (Graphics2D) g;
		FontMetrics fontMetrics = pickFont(g2, name,width);
        int rectWidth = width - 2*padding;
        int labely = height -fontMetrics.getDescent() - 3;
        int rectHeight = labely - fontMetrics.getMaxAscent() - padding;
        cupHeight = rectHeight/capacity - 1;
 
        if (active) {
        	g2.setPaint(SwingVM.active_color);
        	g2.setStroke(SwingVM.wstroke);
        }
        
        g2.draw(new Rectangle2D.Double(x+padding, y+padding, rectWidth, rectHeight));
        g2.setStroke(SwingVM.bstroke);
        for(int i=0; i<currentQuantity; i++) {
        	int yStart=i*cupHeight;
	        int[] xCord = {x+padding+15, x+padding+rectWidth-15, x+padding+rectWidth-((rectWidth-baseWidth)/2)-5, x+padding+((rectWidth-baseWidth)/2)+5};
	        int[] yCord = {y+padding+5+yStart, y+padding+5+yStart, y+padding+5+cupHeight+yStart, y+padding+5+cupHeight+yStart};
	        g2.drawPolygon(xCord, yCord, 4);
        }
        g2.setPaint(SwingVM.fg_color);
        g2.setStroke(SwingVM.stroke);

        g2.drawString(name, x + padding, y+labely);
	
	}
	

}
