package project.hw.gui;

import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;

import tuc.ece.cs201.vm.hw.device.Device;


public abstract class GraphicDevice implements Device {
	String name;
	boolean active;

	int x;
	int y;
	int width;
	int height;
	int padding;
		
    
    final static int maxCharHeight = 15;
    final static int minFontSize = 6;
	
	
	public GraphicDevice(String name, int x, int y, int width, int height, int padding) {
		this.name = name;
		this.padding = padding;
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
	}
	

	FontMetrics pickFont(Graphics2D g2, String longString, int xSpace) {
		boolean fontFits = false;
		Font font = g2.getFont();
		FontMetrics fontMetrics = g2.getFontMetrics();
		int size = font.getSize();
		String name = font.getName();
		int style = font.getStyle();
		
		while ( !fontFits ) {
			if ( (fontMetrics.getHeight() <= maxCharHeight) && 
				 (fontMetrics.stringWidth(longString) <= xSpace) ) {
			   fontFits = true;
			}
			else {
			   if ( size <= minFontSize )
			       fontFits = true;
			   else {
			       g2.setFont(font = new Font(name,style,--size));
			       fontMetrics = g2.getFontMetrics();
			   }
			}
		}

		return fontMetrics;
	}
	
	public void activate() {
		active = true;
		SwingVM.getInstance().refresh();
	}


	public void deActivate() {
		active = false;
		SwingVM.getInstance().refresh();
	}

	public boolean isActive() {
		return active;
	}

	@Override
	public String getName() {
		return name;
	}
	
	public abstract void draw(Graphics g);

}
