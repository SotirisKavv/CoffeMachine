package project.hw.gui;

import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

import tuc.ece.cs201.vm.hw.device.Device;
import tuc.ece.cs201.vm.hw.device.NumPadDevice;


public class SwingNumPad extends JPanel implements  ActionListener, NumPadDevice {

	private static final long serialVersionUID = -7932146601281199241L;

	ButtonArray jnumpad;
	JLabel jlabel;
	
	int keyPressed = -1;
	boolean active;
	
	public SwingNumPad() {
		jlabel = new JLabel("Numpad");
		jlabel.setAlignmentX(LEFT_ALIGNMENT);
		jnumpad = new ButtonArray(this);
		jnumpad.setAlignmentX(LEFT_ALIGNMENT);
		this.setLayout(new BoxLayout(this,BoxLayout.PAGE_AXIS));
		this.setPreferredSize(new Dimension(250, 150));
		this.add(jlabel);
		this.add(jnumpad);
		this.setBorder(BorderFactory.createEmptyBorder(10,10,10,10));
		jnumpad.setEnabled(active);
	}
	
	public synchronized void actionPerformed(ActionEvent ev) {
		try {
			keyPressed = Integer.parseInt(ev.getActionCommand());
		} 
		catch(NumberFormatException ex) {
			keyPressed = -1;
		}
		notify();
	}

	public synchronized int readDigit(String c){		
		keyPressed=-1;
		try {
			wait();
		} catch (InterruptedException e) {			
			e.printStackTrace();
		}
		return keyPressed;
	}
	

	class ButtonArray extends JPanel {
		
		private static final long serialVersionUID = -8458163322167546026L;
		
		JButton[] b = new JButton[10];
		
		public ButtonArray(ActionListener al) {
			GridLayout gl = new GridLayout(0,3);
			this.setLayout(gl);
			for (int i=1;i<10;i++) {
				b[i] = new JButton(""+i);
				this.add(b[i]);
				b[i].addActionListener(al);
			}
			b[0] = new JButton("0");
			this.add(b[0]);
			b[0].addActionListener(al);
		}
		
		public void setEnabled(boolean st) {
			for (int i=0;i<this.getComponentCount();i++) {				
				this.getComponent(i).setEnabled(st);
			}
		}

	}


	@Override
	public boolean isLocked() {
		return active;
	}


	@Override
	public void lock() {
		this.setBackground(SwingVM.deactive_color);
		jnumpad.setEnabled(false);
		active = false;
	}


	@Override
	public void unLock() {
		this.setBackground(SwingVM.active_color);
		jnumpad.setEnabled(true);
		active = true;
	}


	@Override
	public void connect(Device arg0) {
		// TODO Write code...
		
	}


	@Override
	public void disconnect(Device arg0) {
		// TODO Write code...
		
	}


	@Override
	public void disconnectAll() {
		// TODO Write code...
		
	}


	@Override
	public List<Device> listConnectedDevices() {
		// TODO Write code...
		return null;
	}

	
}

