package project.hw.hardwareMachine;

import project.sw.exceptions.ClosedDeviceException;
import tuc.ece.cs201.vm.hw.device.DeviceType;

public class DosingContainerDevice extends ContainerDevice implements tuc.ece.cs201.vm.hw.device.DosingContainerDevice{
	
	public DosingContainerDevice(String name, DeviceType type, int capacity) {
		super(name, type, capacity);
	}
	
	public void releaseDose(tuc.ece.cs201.vm.hw.device.Device toDevice){
		
		((ProcessorDevice)toDevice).open();
		if(!((ProcessorDevice) toDevice).isOpen()){
			try {
				throw new ClosedDeviceException(toDevice.getName()+" is Closed");
			} catch (ClosedDeviceException e) {
				System.out.println(e.getMessage());
			}
		}
		
		System.out.println(this.getName()+ " released  a dose of "+ this.doseSize() +" gr.");
		
		
	}
	
	public int doseSize() {
		return 5;
	}
}
