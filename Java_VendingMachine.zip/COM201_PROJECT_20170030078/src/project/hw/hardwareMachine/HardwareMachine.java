package project.hw.hardwareMachine;

import java.util.ArrayList;
import java.util.List;

import tuc.ece.cs201.vm.hw.device.DeviceType;

public class HardwareMachine implements tuc.ece.cs201.vm.hw.HardwareMachine{
	
	List<tuc.ece.cs201.vm.hw.device.Device> devices;
	private String model;
	
	public HardwareMachine(String model) {
		this.devices = new ArrayList<>();
		this.model = model;
		
		DispenserDevice<ContainerDevice> powderDispenser = new DispenserDevice<>("POWDERS", DeviceType.DosingDispenser);
		powderDispenser.addContainer(new DosingContainerDevice("COFFEE", DeviceType.DosingContainer, 200));
		powderDispenser.addContainer(new DosingContainerDevice("SUGAR", DeviceType.DosingContainer, 200));
		powderDispenser.addContainer(new DosingContainerDevice("CINNAMON", DeviceType.DosingContainer, 200));
		powderDispenser.addContainer(new DosingContainerDevice("BROWN_SUGAR", DeviceType.DosingContainer, 200));
		this.addDevice(powderDispenser);
		
		DispenserDevice<ContainerDevice> flowDispenser = new DispenserDevice<>("LIQUIDS", DeviceType.FlowDispenser);
		flowDispenser.addContainer(new FlowContainerDevice("WATER", DeviceType.FlowContainer, 200));
		flowDispenser.addContainer(new FlowContainerDevice("MILK", DeviceType.FlowContainer, 200));
		flowDispenser.addContainer(new FlowContainerDevice("LIGHT_MILK", DeviceType.FlowContainer, 200));
		flowDispenser.addContainer(new FlowContainerDevice("SYRUP", DeviceType.FlowContainer, 200));
		this.addDevice(flowDispenser);
		
		DispenserDevice<ContainerDevice> materialDispenser = new DispenserDevice<>("CUPS", DeviceType.MaterialDispenser);
		materialDispenser.addContainer(new MaterialContainerDevice("BIG_CUP", DeviceType.MaterialContainer, 30) );
		materialDispenser.addContainer(new MaterialContainerDevice("SMALL_CUP", DeviceType.MaterialContainer, 30) );
		this.addDevice(materialDispenser);
		
		NumPadDevice numPad = new NumPadDevice("NUMPAD", DeviceType.NumPad);
		this.addDevice(numPad);
		CoinAcceptorDevice coinAcceptor = new CoinAcceptorDevice("COIN_ACCEPTOR", DeviceType.CoinReader);
		this.addDevice(coinAcceptor);
		ChangeCaseDevice changeCase = new ChangeCaseDevice("CHANGE_CASE", DeviceType.ChangeCase);
		this.addDevice(changeCase);
		DisplayDevice display = new DisplayDevice("DISPLAY_PANEL", DeviceType.Display);
		this.addDevice(display);
		ProductCaseDevice productCase = new ProductCaseDevice("CUP_CASE", DeviceType.ProductCase);
		this.addDevice(productCase);
		
		ProcessorDevice blender = new ProcessorDevice("MIXER", DeviceType.Processor, 400, "mixed");
		this.addDevice(blender);
		ProcessorDevice boiler = new ProcessorDevice("BOILER", DeviceType.Processor, 400, "hot");
		this.addDevice(boiler);
		ProcessorDevice cooler = new ProcessorDevice("COOLER", DeviceType.Processor, 400, "cold");
		this.addDevice(cooler);
		ProcessorDevice buffer = new ProcessorDevice("BUFFER", DeviceType.Processor, 400, null);
		this.addDevice(buffer);
		
		powderDispenser.connect(blender);
		powderDispenser.connect(buffer);
		
		flowDispenser.connect(blender);
		flowDispenser.connect(boiler);
		flowDispenser.connect(cooler);
		flowDispenser.connect(buffer);
		
		boiler.connect(buffer);
		buffer.connect(boiler);
		boiler.connect(blender);
		blender.connect(boiler);
		
		cooler.connect(blender);
		blender.connect(cooler);
		cooler.connect(buffer);
		buffer.connect(cooler);
		
		materialDispenser.connect(blender);
		materialDispenser.connect(buffer);
		
		productCase.connect(blender);
		productCase.connect(buffer);
		productCase.connect(materialDispenser);
		
		
	}
	
	public void setModel(String model) {
		this.model = model;
	}

	public void addDevice(Device dev) {
		this.devices.add(dev);
	}

	public String getModel() {
		return this.model;
	}

	public List<tuc.ece.cs201.vm.hw.device.Device> listDevices() {
		return this.devices;
	}


}
