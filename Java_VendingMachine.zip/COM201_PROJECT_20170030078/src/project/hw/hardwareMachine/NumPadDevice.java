package project.hw.hardwareMachine;

import tuc.ece.cs201.vm.hw.device.DeviceType;
import tuc.eced.cs201.io.StandardInputRead;

public class NumPadDevice extends Lockable implements tuc.ece.cs201.vm.hw.device.NumPadDevice{
	
	StandardInputRead input;
	
	public NumPadDevice(String name, DeviceType type) {
		super(name, type);
		input = new StandardInputRead();
	}
	
	public int readDigit(String currentCode) {
		
		int code=0;
		
		do {
			code=Integer.parseInt(input.readString(currentCode));
		}while(code<0  || code>=10);
		return code;
	}
}
