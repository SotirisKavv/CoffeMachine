package project.hw.hardwareMachine;

import tuc.ece.cs201.vm.hw.device.DeviceType;
import tuc.ece.cs201.vm.hw.device.LockableDevice;

public abstract class Lockable extends Device implements LockableDevice{
	
	private boolean locked;
	
	public Lockable(String name, DeviceType type) {
		super(name, type);
		this.locked = true;
	}
	
	public void lock() {
		this.locked = true;
		System.out.println(this.getName()+" locked");
	}
	
	public void unLock() {
		this.locked = false;
		System.out.println(this.getName()+" unlocked");
	}
	
	public boolean isLocked() {
		return this.locked;
	}

}
