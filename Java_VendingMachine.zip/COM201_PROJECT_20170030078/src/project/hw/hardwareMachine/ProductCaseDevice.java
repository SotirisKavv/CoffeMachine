package project.hw.hardwareMachine;

import project.productBuilder.Product;
import tuc.ece.cs201.vm.hw.device.DeviceType;

public class ProductCaseDevice extends Lockable implements tuc.ece.cs201.vm.hw.device.ProductCaseDevice{

	public ProductCaseDevice(String name, DeviceType type) {
		super(name, type);
	}

	public void loadIngredient(String ingredientType) {
		System.out.println("Loading a(n) "+ingredientType);
		
	}

	public void putMaterial(String materialType) {
		System.out.println("Placing "+materialType);
		
	}
	
	public void giveProduct(Product p) {
		System.out.println("Your Product:");
		System.out.println(p.getContent().get(1).getQuantity()+" ml of "+p.getName()+": ["+p.getCost()+"]");
		System.out.println(p.getContent().get(0).getName()+"("+p.getContent().get(1).getName()+")");
	}
}
