package project.hw.hardwareMachine;

import tuc.ece.cs201.vm.hw.device.DeviceType;

public class FlowContainerDevice extends ContainerDevice implements tuc.ece.cs201.vm.hw.device.FlowContainerDevice{

	public FlowContainerDevice(String name, DeviceType type, int capacity) {
		super(name, type, capacity);
	}
	
	public int streamRate() {
		return 10;
	}
	
	public void streamOut(tuc.ece.cs201.vm.hw.device.Device toDevice) {
		
		System.out.println(this.getName()+" streaming out to "+ toDevice.getName());
		
	}
}
