package project.hw.hardwareMachine;

import java.util.ArrayList;
import java.util.List;

import tuc.ece.cs201.vm.hw.device.DeviceType;

public class DispenserDevice<T extends ContainerDevice> extends Device  implements tuc.ece.cs201.vm.hw.device.DispenserDevice<ContainerDevice>{
	
	List<T> containers;
	
	public DispenserDevice(String name, DeviceType type) {
		super(name, type);
		this.containers = new ArrayList<>();
	}
	
	public List<ContainerDevice> listContainers(){
		return (List<ContainerDevice>) this.containers;
	}
	
	public void addContainer(ContainerDevice containerDevice) {
		this.containers.add((T) containerDevice);
	}
	
	public void removeContainer(String name) {
		
		for (T container : containers) {
			if (container.getName().equals(name))
				this.containers.remove(container);
		}
	}
	
	public void prepareContainer(ContainerDevice containerDevice) {
		
		this.connected.add(containerDevice);
		System.out.println(containerDevice.getName()+" is connected to "+this.getName());
		
	}
}
