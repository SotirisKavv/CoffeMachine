package project.hw.hardwareMachine;

import tuc.ece.cs201.vm.hw.device.DeviceType;

public class ProcessorDevice extends FlowContainerDevice implements tuc.ece.cs201.vm.hw.device.ProcessorDevice{
	
	private String label;
	
	public ProcessorDevice(String name, DeviceType type, int capacity, String label) {
		super(name, type, capacity);
		this.label = label;
	}

	public String getProcessingLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}
	
	public void streamIn() {
		System.out.println(this.getName()+" streaming in");
	}
	
	public void operateStart() {
		System.out.println(this.getName()+" processing started");
	}
	
	public void operateStop() {
		System.out.println(this.getName()+" processing completed");
	}
}
