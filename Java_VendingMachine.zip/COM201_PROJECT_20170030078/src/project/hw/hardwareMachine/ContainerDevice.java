package project.hw.hardwareMachine;

import tuc.ece.cs201.vm.hw.device.DeviceType;

public abstract class ContainerDevice extends Device implements tuc.ece.cs201.vm.hw.device.ContainerDevice{
	
	private boolean closed;
	private int capacity;
	
	public ContainerDevice(String name, DeviceType type, int capacity) {
		super(name, type);
		this.closed = true;
		this.capacity = capacity;
	}
	
	public void close() {
		this.closed = true;
	}
	
	public void open() {
		this.closed = false;
	}
	
	public boolean isOpen() {
		return !this.closed;
	}

	public int getCapacity() {
		return capacity;
	}

	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}
}
