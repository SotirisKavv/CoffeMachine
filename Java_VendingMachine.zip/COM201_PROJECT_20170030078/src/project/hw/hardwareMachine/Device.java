package project.hw.hardwareMachine;

import java.util.ArrayList;
import java.util.List;

import tuc.ece.cs201.vm.hw.device.DeviceType;

public abstract class Device implements tuc.ece.cs201.vm.hw.device.Device{
	
	private String name;
	private DeviceType type;
	List<tuc.ece.cs201.vm.hw.device.Device> connected;
	
	public Device(String name, DeviceType type) {
		this.name = name;
		this.type = type;
		this.connected = new ArrayList<>();
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public DeviceType getType() {
		return type;
	}

	public void setType(DeviceType type) {
		this.type = type;
	}
	
	public void connect(tuc.ece.cs201.vm.hw.device.Device dev) {
		this.connected.add( (Device) dev);
		System.out.println(this.getName()+" connected to "+dev.getName());
	}
	
	public void disconnect(tuc.ece.cs201.vm.hw.device.Device dev) {//add exception
		if (!this.connected.contains(dev)) {
			//throw exception
		}
		this.connected.remove(dev);
		System.out.println("Device disconnected!");
	}
	
	public void disconnectAll() {
		this.connected.clear();
	}
	
	public List<tuc.ece.cs201.vm.hw.device.Device> listConnectedDevices(){
		return this.connected;
	}
	
}
