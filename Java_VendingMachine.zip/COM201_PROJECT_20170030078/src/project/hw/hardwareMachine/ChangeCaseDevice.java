package project.hw.hardwareMachine;

import tuc.ece.cs201.vm.hw.device.DeviceType;

public class ChangeCaseDevice extends Lockable implements tuc.ece.cs201.vm.hw.device.ChangeCaseDevice{
	
	public ChangeCaseDevice(String name, DeviceType type) {
		super(name, type);
	}
	
	public void giveChange(int coin) {
		System.out.println("Your Change: ("+coin+")");
	}
	
	public void removeChange() {
		System.out.println("Change Case is Empty");
	}

}
