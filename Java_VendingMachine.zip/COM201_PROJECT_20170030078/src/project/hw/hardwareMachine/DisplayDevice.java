package project.hw.hardwareMachine;

import tuc.ece.cs201.vm.hw.device.DeviceType;

public class DisplayDevice extends Device implements tuc.ece.cs201.vm.hw.device.DisplayDevice{

	public DisplayDevice(String name, DeviceType type) {
		super(name, type);
	}

	
	public void clear() {
		System.out.print("\033[H\033[2J");  
	    System.out.flush();  
		
	}

	public void displayMsg(String txt) {
		System.out.println(txt);
		
	}

}
