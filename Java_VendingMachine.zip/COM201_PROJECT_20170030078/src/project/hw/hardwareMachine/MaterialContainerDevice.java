package project.hw.hardwareMachine;

import tuc.ece.cs201.vm.hw.device.DeviceType;

public class MaterialContainerDevice extends ContainerDevice implements tuc.ece.cs201.vm.hw.device.MaterialContainerDevice{

	public MaterialContainerDevice(String name, DeviceType type, int capacity) {
		super(name, type, capacity);
	}
	
	public void releaseMaterial(tuc.ece.cs201.vm.hw.device.Device toDevice) {
		
	}
}
