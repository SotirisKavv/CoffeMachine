package project.hw.hardwareMachine;

import tuc.ece.cs201.vm.hw.device.DeviceType;
import tuc.eced.cs201.io.StandardInputRead;


public class CoinAcceptorDevice extends Lockable implements tuc.ece.cs201.vm.hw.device.CoinAcceptorDevice{
	
	StandardInputRead input;
	
	public CoinAcceptorDevice(String name, DeviceType type) {
		super(name, type);
	}
	
	public int acceptCoin(int subTotal) {
		
		if(subTotal!=1 && subTotal!=2 && subTotal!=5 && subTotal!=10 && subTotal!=20 && subTotal!=50 && subTotal!=100 && subTotal!=200) {
			System.out.println("Not Acceptable Coin!");
			return 0;
		} else
			return subTotal;
	}

}
