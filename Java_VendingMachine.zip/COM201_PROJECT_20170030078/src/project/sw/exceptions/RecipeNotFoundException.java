package project.sw.exceptions;

public class RecipeNotFoundException extends Exception{
	
	private static final long serialVersionUID = 1L;

	public RecipeNotFoundException(String message) {
		super(message);
	}
}
