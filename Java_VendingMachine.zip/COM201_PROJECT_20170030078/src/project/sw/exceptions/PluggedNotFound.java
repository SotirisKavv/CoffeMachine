package project.sw.exceptions;

public class PluggedNotFound extends Exception{
	
	private static final long serialVersionUID = 1L;
	
	public PluggedNotFound(String message) {
        super(message);
    }
}
