package project.sw.exceptions;

public class ContainerNotFound extends Exception{
	private static final long serialVersionUID = 1L;
	
	public ContainerNotFound(String message) {
        super(message);
    }
}
