package project.sw.exceptions;

public class ModuleNotFoundException extends Exception{
	
	private static final long serialVersionUID = 1L;
	
	public ModuleNotFoundException(String message) {
		super(message);
	}
}
