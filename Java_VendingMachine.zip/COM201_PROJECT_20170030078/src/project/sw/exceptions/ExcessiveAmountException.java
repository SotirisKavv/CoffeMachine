package project.sw.exceptions;

public class ExcessiveAmountException extends Exception{
	private static final long serialVersionUID = 1L;
	
	public ExcessiveAmountException(String message) {
        super(message);
    }
}
