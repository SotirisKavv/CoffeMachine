package project.sw.exceptions;

public class LockedModuleException extends Exception{

private static final long serialVersionUID = 1L;
	
	public LockedModuleException(String message) {
        super(message);
    }
}
