package project.sw.exceptions;

public class LowQuantityException extends Exception{
	private static final long serialVersionUID = 1L;
	
	public LowQuantityException(String message) {
        super(message);
    }
}
