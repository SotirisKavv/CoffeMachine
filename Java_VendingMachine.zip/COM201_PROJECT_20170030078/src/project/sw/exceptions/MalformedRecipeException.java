package project.sw.exceptions;

public class MalformedRecipeException extends Exception {
    
	private static final long serialVersionUID = 1L;

	public MalformedRecipeException(String message) {
        super(message);
    }
}
