package project.sw.exceptions;

public class IncompatibilityException extends Exception{
	
	private static final long serialVersionUID = 1L;
	
	public IncompatibilityException(String message) {
        super(message);
    }
}
