package project.sw.recipe;

import project.consumables.Ingredient;
import project.consumables.Liquid;
import project.consumables.Powder;
import project.sw.exceptions.ContainerNotFound;
import project.sw.exceptions.MalformedRecipeException;


import java.util.*;


public class Recipe {
    private String name;
    private int code;
    private int cost;    
    private boolean active;
    private String type;
    private LinkedList<RecipeStep> steps;
    private LinkedList<Ingredient> ingredients;
    int i=0;
    

    public String getName() {
        return name;
    }

    public int getCost() {
        return cost;
    }

    public String getType() {
        return type;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setCost(int cost) {
        this.cost = cost;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public Recipe() {
        this.active=true;
        this.steps = new LinkedList<>();
        this.setIngredients(new LinkedList<>());
        type = "DefaultDrink";
    }

    public Recipe(String name) {
        this();
        this.name = name;
    }

    public Recipe(String name, int code) {
        this(name);
        this.code = code;
    }

    public Recipe(int code){
        this();
        this.code=code;
    }

    public Recipe(String name, int code, int cost) {
        this(name,code);
        this.cost = cost;

    }

    public Recipe(String name, int code, int cost, String type) {
        this(name, code, cost);
        this.type = type;
    }

    public void addStep(RecipeStep step) {
        this.steps.add(step);
    }

    public boolean isEnabled() {
        return active;
    }

    public void enable() {
        this.active = true;
    }

    public void disable(){
        this.active=false;
    }

    public boolean hasMoreSteps() {
        return (i<steps.size() && steps.get(i)!=null);
    }

    public RecipeStep getNextStep() {      
            return steps.get(i++);      
    }

    public void unMarshal(String recipeTxt) throws MalformedRecipeException, ContainerNotFound {
    	
    	RecipeStep rs;
    	
    	if(recipeTxt.substring(0, recipeTxt.indexOf(":")).equalsIgnoreCase("name")) {
    		this.name = recipeTxt.substring(recipeTxt.indexOf(":")+2, recipeTxt.indexOf("\n"));
    		recipeTxt = recipeTxt.substring(recipeTxt.indexOf("\n")+1);
    	}
    	if(recipeTxt.substring(0, recipeTxt.indexOf(":")).equalsIgnoreCase("type")) {
    		this.type = recipeTxt.substring(recipeTxt.indexOf(":")+2, recipeTxt.indexOf("\n"));
    		recipeTxt = recipeTxt.substring(recipeTxt.indexOf("\n")+1);
    	}
    	if(recipeTxt.substring(0, recipeTxt.indexOf(":")).equalsIgnoreCase("price")) {
    		this.cost = Integer.parseInt(recipeTxt.substring(recipeTxt.indexOf(":")+2, recipeTxt.indexOf("\n")));
    		recipeTxt = recipeTxt.substring(recipeTxt.indexOf("\n")+1);
    	}
    	if(recipeTxt.substring(0, recipeTxt.indexOf(":")).equalsIgnoreCase("ingredients")) {
    		recipeTxt = recipeTxt.substring(recipeTxt.indexOf(":")+2);
   			String tempTxt = recipeTxt.substring(0, recipeTxt.indexOf("\n"));
   			String[] ings = tempTxt.split(",");
   			for(int i=0; i<ings.length; i++) {
	   			Ingredient ing;
	   			String[] tmp = ings[i].split(":");
	   			if (tmp[0].equalsIgnoreCase("pwd"))
	   				ing = new Powder(tmp[1], Integer.parseInt(tmp[2]));
	   			else if (tmp[0].equalsIgnoreCase("liq"))
	   				ing = new Liquid(tmp[1], Integer.parseInt(tmp[2]));
	   			else
	   				throw new ContainerNotFound("Not supportable Ingredient");
	   			this.ingredients.add(ing);
   			}
    		recipeTxt = recipeTxt.substring(recipeTxt.indexOf("\n")+1);
    	}
    	if(recipeTxt.substring(0, recipeTxt.indexOf("\n")).equalsIgnoreCase("recipe steps:")) {
    		recipeTxt= recipeTxt.substring(recipeTxt.indexOf("\n")+1);
    		while(recipeTxt.indexOf("\n")!=-1) {    		
	    		if(recipeTxt.substring(0, recipeTxt.indexOf(" ")).equalsIgnoreCase("transfer"))
					rs = new TransferStep();
	    		else 
	    			rs = new OperateStep();
	    		this.addStep(rs);
	    		recipeTxt = recipeTxt.substring(recipeTxt.indexOf(" ")+1);
	    		rs.unMarshal(recipeTxt);
	    		recipeTxt = recipeTxt.substring(recipeTxt.indexOf("\n")+1);
    		 }
    		if(recipeTxt.substring(0, recipeTxt.indexOf(" ")).equalsIgnoreCase("transfer"))
				rs = new TransferStep();
    		else 
    			rs = new OperateStep();
    		this.addStep(rs);
    		recipeTxt = recipeTxt.substring(recipeTxt.indexOf(" ")+1);
    		rs.unMarshalLast(recipeTxt);
    	}
    }
    
    public String marshal() {
        String marshal="";
        marshal+="Name: "+this.getName()+"\n";
        marshal+="Type: "+this.getType()+"\n";
        marshal+="Price: "+this.getCost()+"\n";
        marshal+="Ingredients: ";
        for (Ingredient i : this.ingredients){
            if (i instanceof Powder){
                marshal+="PWD:";
            }else{
                marshal+="LIQ:";
            }
            marshal+=i.getName()+":"+i.getQuantity()+",";
        }
        marshal=marshal.substring(0, marshal.lastIndexOf(",")-1)+"\n";
        marshal+="Recipe Steps:\n";
        for (RecipeStep rs = this.steps.get(0); this.hasMoreSteps(); rs=this.getNextStep()) {
        	marshal+=rs.marshal()+"\n";
        }
        i=0;
        return marshal;
    }
    

    public void print(){
        System.out.println(this.type + ": "+ this.name + ", Price: " + this.cost);
        for (RecipeStep step : steps) {
            step.print();
        }
    }

	public LinkedList<Ingredient> getIngredients() {
		return ingredients;
	}

	public void setIngredients(LinkedList<Ingredient> ingredients) {
		this.ingredients = ingredients;
	}

}