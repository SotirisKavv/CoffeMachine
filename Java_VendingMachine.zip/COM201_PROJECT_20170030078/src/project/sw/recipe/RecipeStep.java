package project.sw.recipe;

import project.sw.exceptions.ModuleNotFoundException;
import project.sw.vendingMachine.VendingMachine;

public abstract class RecipeStep {

    public abstract void print();
    
    public abstract void unMarshal(String text);
    
    public abstract void unMarshalLast(String text);
    
    public void executeStep() throws ModuleNotFoundException{
    	System.out.print("EXECUTING STEP: ");
    }
    
    public abstract String marshal(); 

}
