package project.sw.recipe;

import project.consumables.Ingredient;
import project.consumables.Powder;
import project.sw.dao.DAOFactory;
import project.sw.dao.RecipeDAO;
import project.sw.exceptions.ModuleNotFoundException;
import project.sw.exceptions.RecipeNotFoundException;
import project.sw.machineModules.external.ProductCase;
import project.sw.machineModules.internal.containers.DosingContainer;
import project.sw.machineModules.internal.containers.FlowContainer;
import project.sw.machineModules.internal.dispensers.ConsumableDispenser;
import project.sw.vendingMachine.VendingMachine;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class RecipeManager {    
    DAOFactory daoFactory;
    RecipeDAO recipeDAO;    
    private int numOfEnabled;
    private boolean loaded;
    private HashMap<Integer,Recipe> recipes;

    public RecipeManager() throws IllegalAccessException {
        daoFactory = DAOFactory.getDAOFactory("FS");
        this.recipes = new HashMap<>();
        this.numOfEnabled =0;
        this.loaded=false;
    }

    public void loadRecipes(){
        recipeDAO = daoFactory.getRecipeDAO();
        for (Recipe r : recipeDAO.loadRecipes()){
            this.recipes.put(r.getCode(),r);
        }
        this.loaded=true; 
        this.numOfEnabled = this.recipes.size();
    }

    public int getNumOfEnabled() {
        return numOfEnabled;
    }

    public Recipe getRecipe(Integer code) throws RecipeNotFoundException{
        
    	Recipe rec = recipes.get(code);
    	if(rec==null) {
    		throw new RecipeNotFoundException("Recipe with code "+code+" wasn't Found");
    	}
    	return rec;
    }

    public List<Recipe> getRecipes(){
        if (!loaded){
            this.loadRecipes();
        }
        return new ArrayList<>(this.recipes.values());
    }
    
    public void execute(Recipe r) throws ModuleNotFoundException, IllegalAccessException {
    	VendingMachine vm = VendingMachine.getInstance();
    	ProductCase pc = (ProductCase) vm.getModule("CUP_CASE");
    	pc.prepareProduct(r.getType(), r.getName(), r.getCost());
    	while(r.hasMoreSteps()) {
    		r.getNextStep().executeStep();
    		System.out.println("");
    	}
    }
    
    public void loadEnabledRecipes() throws ModuleNotFoundException {
    	VendingMachine vm = VendingMachine.getInstance();
    	for (Recipe r: this.getRecipes()) {
			for(Ingredient ing: r.getIngredients()) {
				if (ing instanceof Powder) {
					ConsumableDispenser<DosingContainer> dc =(ConsumableDispenser<DosingContainer>)vm.getModule("POWDERS");
					if(dc.getContainer(ing.getName()).getContent().getQuantity()<ing.getQuantity()){
						r.disable();
						this.numOfEnabled--;
						break;
					}
				} else {
					ConsumableDispenser<FlowContainer> fc =(ConsumableDispenser<FlowContainer>)vm.getModule("LIQUIDS");
					if(fc.getContainer(ing.getName()).getContent().getQuantity()<ing.getQuantity()){
						r.disable();
						this.numOfEnabled--;
						break;
					}
				}
			}
		}
    }

}
