
package project.sw.recipe;

import project.sw.dispenserModules.internal.processor.IngredientProcessor;
import project.sw.exceptions.ClosedDeviceException;
import project.sw.exceptions.ModuleNotFoundException;
import project.sw.vendingMachine.VendingMachine;

public class OperateStep extends RecipeStep {
    private String processor;
    private int duration;
    
    public OperateStep(String processor, int duration){
        this.processor=processor;
        this.duration = duration;
    }

    public OperateStep() {
		
	}

	public String getProcessor() {
        return processor;
    }

    public void setProcessor(String processor) {
        this.processor = processor;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    public String toString(){
        return "OPERATE "+ this.processor + " " + this.duration;
    }

    public void print() {
        System.out.println("OPERATE " + this.processor + " "+ this.duration);
    }

	public void unMarshal(String text) {
		this.processor=text.substring(0, text.indexOf(" "));
		text = text.substring(text.indexOf(" ")+1);
		this.duration = Integer.parseInt(text.substring(0, text.indexOf("\n")));
	}
	
	public void unMarshalLast(String text) {
		this.processor=text.substring(0, text.indexOf(" "));
		text = text.substring(text.indexOf(" ")+1);
		this.duration = Integer.parseInt(text);
	}
	
	public String marshal() {
		String marshal ="";
		marshal+="OPERATE ";
		marshal+=this.processor+" ";
		marshal+=this.duration;
		
		return marshal;
	}

	public void executeStep() throws ModuleNotFoundException {
		super.executeStep();
		VendingMachine vm = VendingMachine.getInstance();
		System.out.println(this.marshal());
		try {
			((IngredientProcessor)vm.getModule(this.getProcessor())).process(this.getDuration());
		} catch (ClosedDeviceException e) {
			e.printStackTrace();
		}
		
	}
}
