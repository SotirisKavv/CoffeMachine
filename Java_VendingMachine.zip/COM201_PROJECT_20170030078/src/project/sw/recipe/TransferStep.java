
package project.sw.recipe;


import project.hw.hardwareMachine.ContainerDevice;
import project.sw.dispenserModules.internal.processor.IngredientProcessor;
import project.sw.exceptions.*;
import project.sw.machineModules.internal.consumers.Consumer;
import project.sw.machineModules.internal.containers.Container;
import project.sw.machineModules.internal.dispensers.ConsumableDispenser;
import project.sw.vendingMachine.VendingMachine;
import project.sw.vendingMachine.Module;

public class TransferStep extends RecipeStep{
    private String from;
    private String to;
    private String what;
    private  int quantity;
    
    public TransferStep(String f, String t, String w, int q){
        this.from=f;
        this.to =t;
        this.what=w;
        this.quantity=q;
    }

    public TransferStep() {
		
	}

	public String getFrom() {
        return from;
    }

    public void setFrom(String from) {
        this.from = from;
    }

    public String getTo() {
        return to;
    }

    public void setTo(String to) {
        this.to = to;
    }

    public String getWhat() {
        return what;
    }

    public void setWhat(String what) {
        this.what = what;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String toString(){
        return "TRANSFER "+ this.from + " " + this.to + " " + this.what + " " + this.quantity;
    }

    public void print() {
        System.out.println("TRANSFER " + this.from + " " + this.to + " " + this.what + " "+this.quantity);
    }

	
	public void unMarshal(String text) {
		this.from = text.substring(0, text.indexOf(" "));
		text = text.substring(text.indexOf(" ")+1);
		this.to = text.substring(0, text.indexOf(" "));
		text = text.substring(text.indexOf(" ")+1);
		this.what = text.substring(0, text.indexOf(" "));
		text = text.substring(text.indexOf(" ")+1);
		this.quantity = Integer.parseInt(text.substring(0, text.indexOf("\n")));
	}
	
	public void unMarshalLast(String text) {
		this.from = text.substring(0, text.indexOf(" "));
		text = text.substring(text.indexOf(" ")+1);
		this.to = text.substring(0, text.indexOf(" "));
		text = text.substring(text.indexOf(" ")+1);
		this.what = text.substring(0, text.indexOf(" "));
		text = text.substring(text.indexOf(" ")+1);
		this.quantity = Integer.parseInt(text);
	}
	
	public String marshal() {
		String marshal="";
		marshal+="TRANSFER ";
		marshal+=this.from+" "+this.to+" "+this.what+" "+this.quantity;
		
		return marshal;
	}


	public void executeStep() throws ModuleNotFoundException {
		super.executeStep();
		System.out.println(this.toString());
		VendingMachine vm = VendingMachine.getInstance();
		try {
			Module<?> from = vm.getModule(this.getFrom());
			if (Class.forName("project.sw.machineModules.internal.dispensers.ConsumableDispenser").isInstance(from)) {
				Module<?> to =  vm.getModule(this.getTo());
				Container<ContainerDevice> container = (Container<ContainerDevice>) ((ConsumableDispenser<Container<?>>) from).getContainer(this.getWhat());
				((ConsumableDispenser<Container<?>>) from).prepareContainer(container.getName(), (Consumer) to);
				if(this.getQuantity()>0)
					container.provide((Consumer) to, this.getQuantity());
				else
					container.provide((Consumer) to);
			} else if (Class.forName("project.sw.dispenserModules.internal.processor.IngredientProcessor").isInstance(from)) {
				Module<?> to =  vm.getModule(this.getTo());
				((IngredientProcessor)from).provide((Consumer)to);
			}
			this.wait(2);
		} catch (IncompatibilityException | LowQuantityException | PluggedNotFound | ExcessiveAmountException | ClassNotFoundException | ContainerNotFound | ClosedDeviceException e) {
			System.out.println(e.getMessage());
		}
		
	}
	
	public void wait(int sec) {
		try {
			Thread.sleep(sec*1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}
