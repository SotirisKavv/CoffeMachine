package project.sw.vendingMachine;

import project.sw.exceptions.PluggedNotFound;
import project.sw.machineModules.internal.consumers.Consumer;

public interface Pluggable {
	
	public void plug(Consumer conRef);
	
	public void unPlug(Consumer conRef) throws PluggedNotFound;
	
	public boolean isPlugged();
	
	public void unPlugAll();
}
