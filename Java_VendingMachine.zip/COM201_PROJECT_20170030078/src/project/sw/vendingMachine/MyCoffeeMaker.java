package project.sw.vendingMachine;

import project.hw.gui.SwingVM;
import project.hw.hardwareMachine.HardwareMachine;

public class MyCoffeeMaker {

	public static void main(String[] args) {
		
		HardwareMachine hw = new HardwareMachine("Nesspresso");
		SwingVM svm = SwingVM.getInstance();
				
		VendingMachine vm = VendingMachine.getInstance();
		vm.initMachine(hw);
		
		CoffeeCPU cpu = new CoffeeCPU();
 		cpu.run();
		
	}
}