package project.sw.vendingMachine;

import tuc.ece.cs201.vm.hw.device.Device;

public abstract class Module<T extends Device> {
	
	protected String name;
	protected T device;

	public Module(T device) {
		this.device = device;
		this.name = device.getName();
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public T getDevice() {
		return device;
	}

	public void setDevice(T device) {
		this.device = device;
	}	
	
}
