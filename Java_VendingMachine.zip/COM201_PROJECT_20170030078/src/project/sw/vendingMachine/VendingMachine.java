package project.sw.vendingMachine;

import java.util.*;

import tuc.ece.cs201.vm.hw.*;
import project.sw.dao.ModuleFactory;
import project.sw.exceptions.ModuleNotFoundException;
import project.sw.machineModules.internal.containers.DosingContainer;
import project.sw.machineModules.internal.containers.FlowContainer;
import project.sw.machineModules.internal.containers.MaterialContainer;
import project.sw.machineModules.internal.dispensers.ConsumableDispenser;
import tuc.ece.cs201.vm.hw.device.ContainerDevice;
import tuc.ece.cs201.vm.hw.device.DeviceType;
import tuc.ece.cs201.vm.hw.device.DispenserDevice;
import tuc.ece.cs201.vm.hw.device.DosingContainerDevice;
import tuc.ece.cs201.vm.hw.device.FlowContainerDevice;
import tuc.ece.cs201.vm.hw.device.MaterialContainerDevice;

public class VendingMachine {
	
	private HashMap<String, Module<?>> modules;
	
	private static VendingMachine instance;
	
	private VendingMachine() {
		this.modules = new HashMap<>();
	}
	
	private VendingMachine(HardwareMachine hw) {
		this.modules = new HashMap<>();
		this.probeHardware(hw);
	}
	
	public void initMachine(HardwareMachine machine) {
		if (!modules.isEmpty())
			throw new AssertionError("Software Machine has already been initialized based on a HardwareMachine");
		this.probeHardware(machine);
	}
	
	public static VendingMachine getInstance() {
		if (instance!=null)
			return instance;
		else
			instance = new VendingMachine();
		return instance;
	}
	
	public void addModule(Module<?> m) {
		this.modules.put(m.getName(), m);
	}
	
	public Module<?> getModule(String name) throws ModuleNotFoundException{ //add exception
		if (!modules.containsKey(name)) {
			throw new ModuleNotFoundException(name+" wasn't Found");
		}
		return modules.get(name);
	}
	
	private Module<?> createModule(tuc.ece.cs201.vm.hw.device.Device dev) {
		return ModuleFactory.createModule(dev);
	}
	
	private void probeHardware(HardwareMachine machine) {
		for (tuc.ece.cs201.vm.hw.device.Device dev : machine.listDevices()) {
			Module<?> module = this.createModule(dev);
			if (module.getDevice().getType().equals(DeviceType.FlowDispenser)) {
				List<FlowContainerDevice> containers = ((DispenserDevice<FlowContainerDevice>) module.getDevice()).listContainers();
				for (ContainerDevice c : containers) {
					((ConsumableDispenser) module).addContainer((FlowContainer)this.createModule(c));
				}
			}
			if (module.getDevice().getType().equals(DeviceType.DosingDispenser)) {
				List<DosingContainerDevice> containers = ((DispenserDevice<DosingContainerDevice>) module.getDevice()).listContainers();
				for (ContainerDevice c : containers) {
					((ConsumableDispenser) module).addContainer((DosingContainer)this.createModule(c));
				}
			}
			if (module.getDevice().getType().equals(DeviceType.MaterialDispenser)) {
				List<MaterialContainerDevice> containers = ((DispenserDevice<MaterialContainerDevice>) module.getDevice()).listContainers();
				for (ContainerDevice c : containers) {
					((ConsumableDispenser) module).addContainer((MaterialContainer)this.createModule(c));
				}
			}
				
			this.addModule(module);
		}
	}
}
