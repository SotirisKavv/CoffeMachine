package project.sw.vendingMachine;

import project.sw.exceptions.LockedModuleException;
import project.sw.exceptions.ModuleNotFoundException;
import project.sw.exceptions.RecipeNotFoundException;
import project.sw.machineModules.external.ChangeCase;
import project.sw.machineModules.external.CoinReader;
import project.sw.machineModules.external.DisplayPanel;
import project.sw.machineModules.external.NumPad;
import project.sw.machineModules.external.ProductCase;
import project.sw.recipe.Recipe;
import project.sw.recipe.RecipeManager;


public class CoffeeCPU {
	
	public void run() {
		
		VendingMachine vm = VendingMachine.getInstance();
		
		try {
			RecipeManager rManager = new RecipeManager();
			CoinReader cr = (CoinReader) vm.getModule("COIN_ACCEPTOR");
			ChangeCase cc = (ChangeCase) vm.getModule("CHANGE_CASE");
			DisplayPanel sp = (DisplayPanel) vm.getModule("DISPLAY_PANEL");
			NumPad np = (NumPad) vm.getModule("NUMPAD");
			ProductCase pc = (ProductCase) vm.getModule("CUP_CASE");
			
			while(true) {
				rManager.loadRecipes();
				rManager.loadEnabledRecipes();
				this.wait(1.0);
				if(rManager.getNumOfEnabled()==0) {
					sp.displayMsg("No Available Recipe\n");
					break;
				}
				sp.displayMsg("Please Choose a Drink:\n");
				for (Recipe r: rManager.getRecipes()) {
					if(r.isEnabled())
						sp.displayMsg(r.getCode()+"   "+r.getName()+"\t["+r.getCost()+"]\n");
				}
				
				Recipe recipe = rManager.getRecipe(np.readCode(3)); 
				this.wait(1.0);
				sp.displayMsg("The cost of a "+recipe.getName()+" is: "+recipe.getCost()+"\n");
				int money = cr.receiveMoney(recipe.getCost());
				this.wait(1.0);
				cc.setChange(money-recipe.getCost());
				cc.getChange();
				cc.removeChange();
				this.wait(1.0);
				System.out.println("");
				System.out.println("Executing Recipe:\n"+recipe.marshal()+"\n");
				rManager.execute(recipe);
				pc.getProduct();
				sp.clearPanel();
			}
		} catch (LockedModuleException | IllegalAccessException | ModuleNotFoundException | RecipeNotFoundException e) {
			System.out.println(e.getMessage());
		}
	}
	
	public void wait(double sec) {
		try {
			Thread.sleep((long) (sec*1000));
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}
