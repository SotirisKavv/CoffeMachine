package project.sw.machineModules.internal.dispensers;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import project.sw.exceptions.ContainerNotFound;
import project.sw.exceptions.PluggedNotFound;
import project.sw.machineModules.internal.consumers.Consumer;
import project.sw.machineModules.internal.containers.Container;
import project.sw.machineModules.internal.providers.Provider;
import project.sw.vendingMachine.Module;
import project.sw.machineModules.external.ProductCase;
import tuc.ece.cs201.vm.hw.device.*;



public class ConsumableDispenser<T extends Container<?>> extends Module<DispenserDevice<ContainerDevice>> implements Dispenser{
	
	HashMap<String, Container<?>> containers;
	List<Consumer> plugged;
	
	public ConsumableDispenser(DispenserDevice<ContainerDevice> device) {
		super(device);
		this.containers = new HashMap<>();
		this.plugged = new ArrayList<>();
	}

	public void plug(Consumer conRef) {
		this.plugged.add(conRef);
		this.device.connect((Device)conRef);
	}

	public void unPlug(Consumer conRef) throws PluggedNotFound {	
		if (!this.plugged.contains(conRef)) {
			throw new PluggedNotFound(conRef.toString()+" not plugged");
		}
		this.plugged.remove(conRef);
	}

	public boolean isPlugged() {
		return (!this.plugged.isEmpty()); 
	}

	public void unPlugAll() {
		this.plugged.clear();
	}

	public Provider prepareContainer(String conName, Consumer confRef) throws ContainerNotFound{
		if (!containers.containsKey(conName)) {
			throw new ContainerNotFound(conName +" not Found");
		}
		try {
			if (Class.forName("project.sw.machineModules.internal.containers.Container").isInstance(confRef))
				this.device.connect((ContainerDevice)((Container<?>)confRef).getDevice());
			else if (Class.forName("project.sw.machineModules.external.ProductCase").isInstance(confRef))
				this.device.connect((ProductCaseDevice)((ProductCase)confRef).getDevice()); 
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		System.out.println("Container "+containers.get(conName).getName()+" is prepared");		
		return containers.get(conName);
	}

	public void addContainer(Container<?> container) {
		 this.containers.put(container.getName(), container);
		 System.out.println(this.getName()+" container "+container.getName()+" added");
	}
	
	public Container<?> getContainer(String conName){
		return this.containers.get(conName);
	}

	public Container<?> removeContainer(String conName) throws ContainerNotFound{ 
		
		Container<?> con;
		
		if (!containers.containsKey(conName)) {
			throw new ContainerNotFound(conName+" wasn't found");
		}
		con=containers.get(conName);
		this.containers.remove(conName);
		System.out.println(con.getName()+" was Removed");
		return con;
	}

	public int getCurrentQuantity(String conName) throws ContainerNotFound{	
		
		if (!containers.containsKey(conName)) {
			throw new ContainerNotFound(conName+" not found");
		}
		
		return this.containers.get(conName).getContent().getQuantity();
	}

}
