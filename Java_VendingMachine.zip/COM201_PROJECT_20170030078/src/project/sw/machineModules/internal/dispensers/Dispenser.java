package project.sw.machineModules.internal.dispensers;

import project.sw.exceptions.ContainerNotFound;
import project.sw.machineModules.internal.consumers.Consumer;
import project.sw.machineModules.internal.containers.Container;
import project.sw.machineModules.internal.providers.Provider;
import project.sw.vendingMachine.Pluggable;

public interface Dispenser extends Pluggable{
	
	public Provider prepareContainer(String conName, Consumer confRef) throws ContainerNotFound;
	
	public void addContainer(Container<?> container);
	
	public Container<?> removeContainer(String conName) throws ContainerNotFound;
	
	public int getCurrentQuantity(String conName) throws ContainerNotFound;
}
