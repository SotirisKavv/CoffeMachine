package project.sw.machineModules.internal.consumers;

import project.consumables.Consumable;
import project.sw.exceptions.ExcessiveAmountException;
import project.sw.exceptions.IncompatibilityException;

public interface Consumer {
	
	public void load(Consumable con) throws ExcessiveAmountException, IncompatibilityException;
	
	public boolean accepts(Consumable con);

}
