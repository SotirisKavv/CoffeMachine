package project.sw.machineModules.internal.providers;

import project.sw.exceptions.ClosedDeviceException;
import project.sw.exceptions.ExcessiveAmountException;
import project.sw.exceptions.IncompatibilityException;
import project.sw.exceptions.LowQuantityException;
import project.sw.exceptions.PluggedNotFound;
import project.sw.machineModules.internal.consumers.Consumer;
import project.sw.vendingMachine.Pluggable;

public interface Provider extends Pluggable{
	
	public void provide(Consumer confRef, int quantity) throws IncompatibilityException, LowQuantityException, PluggedNotFound, ExcessiveAmountException, ClosedDeviceException;
	
	public void provide(Consumer confRef) throws IncompatibilityException, PluggedNotFound, ExcessiveAmountException;
}
