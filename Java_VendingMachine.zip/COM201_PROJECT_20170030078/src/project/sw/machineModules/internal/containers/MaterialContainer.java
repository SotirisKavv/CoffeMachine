package project.sw.machineModules.internal.containers;

import java.util.ArrayList;
import java.util.List;

import project.consumables.Consumable;
import project.hw.gui.SwingVM;
import project.sw.exceptions.ExcessiveAmountException;
import project.sw.exceptions.IncompatibilityException;
import project.sw.exceptions.LowQuantityException;
import project.sw.exceptions.PluggedNotFound;
import project.sw.machineModules.external.ProductCase;
import project.sw.machineModules.internal.consumers.Consumer;
import tuc.ece.cs201.vm.hw.device.MaterialContainerDevice;
import tuc.ece.cs201.vm.hw.device.ProductCaseDevice;


public class MaterialContainer extends Container<MaterialContainerDevice> {

	List<Consumer> plugged;
	
	public MaterialContainer(MaterialContainerDevice container, int capacity, Consumable content) {
		super(container, capacity, content);
		this.plugged = new ArrayList<>();
	}
	
	public void provide(Consumer confRef, int quantity) throws PluggedNotFound, LowQuantityException, IncompatibilityException, ExcessiveAmountException { 	//add quantity exception, incompatible exception
		
		MaterialContainerDevice mContainer = (MaterialContainerDevice)SwingVM.getInstance().getDevice(this.getName());
		ProductCaseDevice pCase = (ProductCaseDevice)SwingVM.getInstance().getDevice(((ProductCase)confRef).getName());
		
		this.plug(confRef);
		
		if(!confRef.accepts(content)) {
			throw new IncompatibilityException(this.getContent().getName()+" is incompatible with "+confRef.toString()+" Consumer.");
		}
		if (quantity>this.content.getQuantity()) {
			throw new LowQuantityException("The Quantity of "+this.getContent().getName()+" is less than needed.");
		}
		
		mContainer.open();
		pCase.unLock();
		mContainer.releaseMaterial(pCase);
		pCase.putMaterial(content.getName());
		confRef.load(this.content.getPart(quantity));
		this.wait(2);
		pCase.lock();
		mContainer.close();
		this.unPlug(confRef);
	}

	public void provide(Consumer confRef) throws IncompatibilityException, PluggedNotFound, ExcessiveAmountException {
		this.plug(confRef);
		
		if(!confRef.accepts(content)) {
			throw new IncompatibilityException(this.getContent().getName()+" is incompatible with "+confRef.toString()+" Consumer.");
		}
				
		confRef.load(this.content);
		
		this.unPlug(confRef);
	}

	public void plug(Consumer confRef) {
		this.plugged.add(confRef);
	}

	public void unPlug(Consumer conRef) throws PluggedNotFound {		
		if (!this.plugged.contains(conRef)) {
			throw new PluggedNotFound(conRef.toString()+" not plugged");
		}
		this.plugged.remove(conRef);
	}

	public boolean isPlugged() {
		return !plugged.isEmpty();
	}

	public void unPlugAll() {
		this.plugged.clear();
	}
	
	public void wait(int x) {
		try {
			Thread.sleep(x*1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

}
