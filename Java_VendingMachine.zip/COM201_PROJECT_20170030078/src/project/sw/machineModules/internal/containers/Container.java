package project.sw.machineModules.internal.containers;

import project.consumables.*;
import project.sw.machineModules.internal.providers.Provider;
import project.sw.vendingMachine.Module;
import tuc.ece.cs201.vm.hw.device.ContainerDevice;

public abstract class Container<T extends ContainerDevice> extends Module<ContainerDevice> implements Provider{
	
	protected int capacity;
	protected Consumable content;
	
	public Container(T container, int capacity, Consumable content) {
		super(container);
		this.capacity = capacity;
		this.content = content;
	}

	public int getCapacity() {
		return capacity;
	}

	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}

	public Consumable getContent() {
		return content;
	}

	public void setContent(Consumable content) {	//add capacity exception
		if (this.capacity<content.getQuantity()) {
			//throw new capacity exception("quantity has exceeded the capacity of the container");
		}
		this.content = content;
	}
}
