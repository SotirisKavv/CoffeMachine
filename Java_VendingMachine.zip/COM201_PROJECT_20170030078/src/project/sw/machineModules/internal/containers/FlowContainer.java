package project.sw.machineModules.internal.containers;

import java.util.ArrayList;
import java.util.List;

import project.consumables.Consumable;
import project.hw.gui.SwingVM;
import project.sw.dispenserModules.internal.processor.IngredientProcessor;
import project.sw.exceptions.ExcessiveAmountException;
import project.sw.exceptions.IncompatibilityException;
import project.sw.exceptions.LowQuantityException;
import project.sw.exceptions.PluggedNotFound;
import project.sw.machineModules.internal.consumers.Consumer;
import tuc.ece.cs201.vm.hw.device.FlowContainerDevice;
import tuc.ece.cs201.vm.hw.device.ProcessorDevice;


public class FlowContainer extends Container<FlowContainerDevice> {
	

	List<Consumer> plugged;
	
	public FlowContainer(FlowContainerDevice container, int capacity, Consumable content) {
		super(container, capacity, content);
		this.plugged = new ArrayList<>();
	}
	
	public void provide(Consumer confRef, int quantity) throws IncompatibilityException, LowQuantityException, PluggedNotFound, ExcessiveAmountException { 	//add quantity exception, incompatible exception
		
		FlowContainerDevice fContainer = (FlowContainerDevice)SwingVM.getInstance().getDevice(this.getName());
		ProcessorDevice gProcessor = (ProcessorDevice)SwingVM.getInstance().getDevice(((IngredientProcessor)confRef).getName());
		
		this.plug(confRef);
		if(!confRef.accepts(content)) {
			throw new IncompatibilityException(this.getContent().getName()+" is incompatible with "+confRef.toString()+" Consumer.");
		}	
		if (quantity>this.content.getQuantity()) {
			throw new LowQuantityException("The Quantity of "+this.getContent().getName()+" is less than needed.");
		}
		fContainer.open();
		gProcessor.open();
		for(int i=0; i<quantity; i+=/*((FlowContainerDevice)this.device).streamRate()*/fContainer.streamRate()) {
			
			//((FlowContainerDevice)this.device).streamOut(((IngredientProcessor)confRef).getDevice());
			fContainer.streamOut(gProcessor);
			//((ProcessorDevice)((IngredientProcessor)confRef).getDevice()).streamIn();
			gProcessor.streamIn();
			this.wait(1);
		}
		fContainer.close();
		gProcessor.close();
		confRef.load(this.content.getPart(quantity));
		this.unPlug(confRef);
	}

	public void provide(Consumer confRef) throws IncompatibilityException, PluggedNotFound, ExcessiveAmountException {
		
		FlowContainerDevice fContainer = (FlowContainerDevice)SwingVM.getInstance().getDevice(this.getName());
		ProcessorDevice gProcessor = (ProcessorDevice)SwingVM.getInstance().getDevice(((IngredientProcessor)confRef).getName());
		
		this.plug(confRef);
		if(!confRef.accepts(content)) {
			throw new IncompatibilityException(this.getContent().getName()+" is incompatible with "+confRef.toString()+" Consumer.");
		}
		fContainer.open();
		gProcessor.open();
		for(int i=0; i<content.getQuantity(); i+=/*((FlowContainerDevice)this.device).streamRate()*/fContainer.streamRate()) {
			
			//((FlowContainerDevice)this.device).streamOut(((IngredientProcessor)confRef).getDevice());
			fContainer.streamOut(gProcessor);
			//((ProcessorDevice)((IngredientProcessor)confRef).getDevice()).streamIn();
			gProcessor.streamIn();
			this.wait(1);
		}
		fContainer.close();
		gProcessor.close();
		confRef.load(this.content);
		this.unPlug(confRef);	
	}

	public void plug(Consumer confRef) {
		this.plugged.add(confRef);
	}

	public void unPlug(Consumer conRef) throws PluggedNotFound {					
		if (!this.plugged.contains(conRef)) {
			throw new PluggedNotFound(conRef.toString()+" not plugged");
		}
		this.plugged.remove(conRef);
	}

	public boolean isPlugged() {
		return !plugged.isEmpty();
	}

	public void unPlugAll() {
		this.plugged.clear();
	}
	
	public void wait(int sec) {
		try {
			Thread.sleep(sec*1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}
