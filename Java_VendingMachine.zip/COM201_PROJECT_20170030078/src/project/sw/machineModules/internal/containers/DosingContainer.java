package project.sw.machineModules.internal.containers;

import java.util.ArrayList;
import java.util.List;

import project.consumables.Consumable;
import project.hw.gui.SwingVM;
import project.sw.dispenserModules.internal.processor.IngredientProcessor;
import project.sw.exceptions.ClosedDeviceException;
import project.sw.exceptions.ExcessiveAmountException;
import project.sw.exceptions.IncompatibilityException;
import project.sw.exceptions.LowQuantityException;
import project.sw.exceptions.PluggedNotFound;
import project.sw.machineModules.internal.consumers.Consumer;
import tuc.ece.cs201.vm.hw.device.Device;
import tuc.ece.cs201.vm.hw.device.DosingContainerDevice;
import tuc.ece.cs201.vm.hw.device.ProcessorDevice;

public class DosingContainer extends Container<DosingContainerDevice> {
	
	List<Consumer> plugged;
	
	public DosingContainer(DosingContainerDevice container, int capacity, Consumable content) {
		super(container, capacity, content);
		this.plugged = new ArrayList<>();
	}
	
	public void provide(Consumer confRef, int quantity) throws IncompatibilityException, LowQuantityException, PluggedNotFound, ExcessiveAmountException, ClosedDeviceException{ 
		
		DosingContainerDevice dContainer = (DosingContainerDevice)SwingVM.getInstance().getDevice(this.getName());
		ProcessorDevice gProcessor = (ProcessorDevice)SwingVM.getInstance().getDevice(((IngredientProcessor)confRef).getName());
		
		this.plug(confRef);
		if (!this.isPlugged()) {
			throw new PluggedNotFound(confRef.toString()+" is not Plugged");
		}
		if(!confRef.accepts(content)) {
			throw new IncompatibilityException(this.getContent().getName()+" is incompatible with "+confRef.toString()+" Consumer.");
		}
		if (quantity>this.content.getQuantity()) {
			throw new LowQuantityException("The Quantity of "+this.getContent().getName()+" is less than needed.");
		}
		
		dContainer.open();
		gProcessor.open();
		for(int i=0; i<quantity; i+=/*((DosingContainerDevice)this.device).doseSize()*/dContainer.doseSize()) {
			
			//((DosingContainerDevice)this.device).releaseDose(((IngredientProcessor)confRef).getDevice());
			dContainer.releaseDose(gProcessor);
			//((ProcessorDevice)((IngredientProcessor)confRef).getDevice()).streamIn();
			gProcessor.streamIn();
			//confRef.load(this.content.getPart(((DosingContainerDevice)this.device).doseSize()));
			this.wait(1.0);
		}
		dContainer.close();
		gProcessor.close();
		confRef.load(this.content.getPart(quantity));
		this.unPlug(confRef);
	}

	public void provide(Consumer confRef) throws IncompatibilityException, PluggedNotFound, ExcessiveAmountException {
		
		DosingContainerDevice dContainer = (DosingContainerDevice)SwingVM.getInstance().getDevice(this.getName());
		ProcessorDevice gProcessor = (ProcessorDevice)SwingVM.getInstance().getDevice(((IngredientProcessor)confRef).getName());
		
		this.plug(confRef);
		if(!confRef.accepts(content)) {
			throw new IncompatibilityException(this.getContent().getName()+" is incompatible with "+confRef.toString()+" Consumer.");
		}	
		dContainer.open();
		gProcessor.open();
		for(int i=0; i<content.getQuantity(); i+=/*((DosingContainerDevice)this.device).doseSize()*/dContainer.doseSize()) {
			
			//((DosingContainerDevice)this.device).releaseDose(((IngredientProcessor)confRef).getDevice());
			dContainer.releaseDose(gProcessor);
			//((ProcessorDevice)((IngredientProcessor)confRef).getDevice()).streamIn();
			gProcessor.streamIn();
			//confRef.load(this.content.getPart(((DosingContainerDevice)this.device).doseSize()));
			this.wait(1.0);
		}
		dContainer.close();
		gProcessor.close();
				confRef.load(this.content);
		this.unPlug(confRef);
	}

	public void plug(Consumer confRef) {
		this.plugged.add(confRef);
	}

	public void unPlug(Consumer conRef) throws PluggedNotFound{			
		
		if (!this.plugged.contains(conRef)) {
			throw new PluggedNotFound(conRef.toString()+" not plugged");
		}
		this.plugged.remove(conRef);
	}

	public boolean isPlugged() {
		return !plugged.isEmpty();
	}

	public void unPlugAll() {
		this.plugged.clear();
	}
	
	public void wait(double sec) {
		try{
			Thread.sleep((long) (sec*1000));
		} catch (InterruptedException ex) {
			ex.printStackTrace();
		}
	}

}
