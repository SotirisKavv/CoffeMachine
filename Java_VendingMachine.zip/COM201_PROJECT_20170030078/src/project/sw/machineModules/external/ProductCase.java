package project.sw.machineModules.external;

import project.consumables.Consumable;
import project.hw.gui.GraphicProductCase;
import project.hw.gui.SwingVM;
import tuc.ece.cs201.vm.hw.device.ProductCaseDevice;
import project.productBuilder.Product;
import project.productBuilder.ProductBuilder;
import project.sw.exceptions.IncompatibilityException;
import project.sw.machineModules.internal.consumers.Consumer;
import project.sw.vendingMachine.Module;


public class ProductCase extends Module<ProductCaseDevice> implements Consumer{
	
	private ProductBuilder pBuilder;
	private Product product;
	
	public ProductCase(ProductCaseDevice pcd) {
		super(pcd);
		this.pBuilder=null;
		this.product = null;
	}

	public void load(Consumable con) throws IncompatibilityException {
		
		ProductCaseDevice pc = (ProductCaseDevice)SwingVM.getInstance().getDevice("CUP_CASE");
		
		if(!this.accepts(con)) {
			throw new IncompatibilityException(this.getName()+" doesn't accept "+con.getName());
		}
		try {
			pc.unLock();
			if (Class.forName("project.consumables.Ingredient").isInstance(con)) {
				//((ProductCaseDevice)this.device).loadIngredient(con.getName());
				pc.loadIngredient(con.getName());
			}
			else if (Class.forName("project.consumables.Material").isInstance(con)) {
				//((ProductCaseDevice)this.device).putMaterial(con.getName());
				pc.putMaterial(con.getName());
			}
			pc.lock();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		pBuilder.addConsumable(con);
		System.out.println(con.getName()+" was loaded");
	}

	public boolean accepts(Consumable con) {
		try {
			return (Class.forName("project.consumables.Consumable").isInstance(con));
		} catch (ClassNotFoundException e) {
			System.out.println("Class "+con.getClass()+" not Found");
			return false;
		}
	}

	public void prepareProduct(String type, String name, int cost) throws IllegalAccessException{
		pBuilder = ProductBuilder.getProductBuilder(type);
		this.product = pBuilder.setName(name).setCost(cost).getProduct();
	}
	
	public Product getProduct() {
		
		ProductCaseDevice pc = (ProductCaseDevice)SwingVM.getInstance().getDevice("CUP_CASE");
		
		//this.device.unLock();
		pc.unLock();
		//((ProductCaseDevice)this.device).giveProduct(product);
		((GraphicProductCase) pc).getProduct();
		//this.device.lock();
		pc.lock();
		return product;
	}

}
