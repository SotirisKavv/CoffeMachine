package project.sw.machineModules.external;

import project.hw.gui.SwingVM;
import project.sw.vendingMachine.Module;
import tuc.ece.cs201.vm.hw.device.DisplayDevice;


public class DisplayPanel extends Module<DisplayDevice> {
	
	public DisplayPanel(DisplayDevice display) {
		super(display);
	}

	public void displayMsg(String msg) {
		
		//this.device.displayMsg(msg);
		
		DisplayDevice sp = (DisplayDevice)SwingVM.getInstance().getDevice("DISPLAY_PANEL");
		sp.displayMsg(msg);
	}
	
	public void clearPanel() {
		//this.device.clear();
		
		DisplayDevice sp = (DisplayDevice)SwingVM.getInstance().getDevice("DISPLAY_PANEL");
		sp.clear();
				
	}

}
