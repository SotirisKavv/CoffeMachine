package project.sw.machineModules.external;


import project.hw.gui.SwingVM;
import project.sw.exceptions.LockedModuleException;
import project.sw.vendingMachine.Module;
import tuc.ece.cs201.vm.hw.device.DisplayDevice;
import tuc.ece.cs201.vm.hw.device.NumPadDevice;

public class NumPad extends Module<NumPadDevice>{
	
	public NumPad(NumPadDevice device) {
		super(device);
	}

	public int readCode(int length) throws LockedModuleException{	
		
		NumPadDevice np = (NumPadDevice)SwingVM.getInstance().getDevice("NUMPAD");
		DisplayDevice sp = (DisplayDevice)SwingVM.getInstance().getDevice("DISPLAY_PANEL");
		
		int code=0;
		String codeStr="";
		//this.device.unLock();
		np.unLock();
		if (/*this.device.isLocked()*/!np.isLocked()) {
			throw new LockedModuleException(this.getName()+" is locked");
		}
		sp.displayMsg("Your code: ");
		for (int i=0; i<length; i++) {
			//code = this.device.readDigit(codeStr);
			code=np.readDigit(codeStr);
			sp.displayMsg(""+code);
			codeStr+=code;
		}
		sp.displayMsg("\n");
		//this.device.lock();
		np.lock();
		
		return Integer.parseInt(codeStr);
	}

}
