package project.sw.machineModules.external;

import project.hw.gui.SwingVM;
import project.sw.exceptions.LockedModuleException;
import project.sw.vendingMachine.Module;
import tuc.ece.cs201.vm.hw.device.CoinAcceptorDevice;
import tuc.ece.cs201.vm.hw.device.DisplayDevice;
import tuc.eced.cs201.io.StandardInputRead;


public  class CoinReader extends Module<CoinAcceptorDevice>{
	
	StandardInputRead input;
	
	public CoinReader(CoinAcceptorDevice cad) {
		super(cad);
		input = new StandardInputRead();
	}
	
	public int receiveMoney(int min) throws LockedModuleException{
		
		CoinAcceptorDevice cr = (CoinAcceptorDevice)SwingVM.getInstance().getDevice("COIN_ACCEPTOR");
		DisplayDevice sp = (DisplayDevice)SwingVM.getInstance().getDevice("DISPLAY_PANEL");
		
		int money=0;
		
		//this.device.unLock();
		cr.unLock();
		if (/*this.device.isLocked()*/!cr.isLocked()) {
			throw new LockedModuleException(this.getName()+" is Locked");
		}
		
		while (money<min) {
			//money+=device.acceptCoin(input.readPositiveInt("Enter a coin: "));
			money+=cr.acceptCoin(0);
			sp.displayMsg("You have paid: "+money+"\n");
		}
		//this.device.lock();
		cr.lock();
		
		return money;
	}
	
}
