package project.sw.machineModules.external;

import project.hw.gui.SwingVM;
import project.sw.exceptions.LockedModuleException;
import project.sw.vendingMachine.Module;
import tuc.ece.cs201.vm.hw.device.ChangeCaseDevice;


public class ChangeCase extends Module<ChangeCaseDevice>{
	
	private int change;
	
	public ChangeCase(ChangeCaseDevice ccd) {
		super(ccd);
		this.change = 0;
	}

	public void setChange(int change){
		this.change = change;
	}

	public void removeChange() throws LockedModuleException {
		
		ChangeCaseDevice cc = (ChangeCaseDevice)SwingVM.getInstance().getDevice("CHANGE_CASE");
		
		this.setChange(0);
		//((ChangeCaseDevice)this.device).removeChange();
		cc.removeChange();
		//this.device.lock();
		cc.lock();
	}
	
	public int getChange() throws LockedModuleException {
		
		ChangeCaseDevice cc = (ChangeCaseDevice)SwingVM.getInstance().getDevice("CHANGE_CASE");
		//this.device.unLock();
		cc.unLock();
		if(/*this.device.isLocked()*/!cc.isLocked()) {
			throw new LockedModuleException(this.getName()+" is Locked!");
		}
		//((ChangeCaseDevice)this.device).giveChange(change);
		cc.giveChange(change);
		return this.change;
	}

}
