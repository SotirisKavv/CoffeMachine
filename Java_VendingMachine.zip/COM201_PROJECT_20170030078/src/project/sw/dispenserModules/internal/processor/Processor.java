package project.sw.dispenserModules.internal.processor;

import project.sw.exceptions.ClosedDeviceException;
import project.sw.machineModules.internal.consumers.Consumer;
import project.sw.vendingMachine.Pluggable;

public interface Processor extends Pluggable, Consumer{
	
	public void process(int duration) throws ClosedDeviceException;
}
