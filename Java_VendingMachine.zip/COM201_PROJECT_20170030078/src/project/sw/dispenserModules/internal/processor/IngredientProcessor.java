package project.sw.dispenserModules.internal.processor;

import java.util.ArrayList;

import project.consumables.Consumable;
import project.consumables.Ingredient;
import project.consumables.ProcessedIngredient;
import project.hw.gui.GraphicProcessor;
import project.hw.gui.SwingVM;
import project.sw.exceptions.ClosedDeviceException;
import project.sw.exceptions.ExcessiveAmountException;
import project.sw.exceptions.IncompatibilityException;
import project.sw.exceptions.LowQuantityException;
import project.sw.exceptions.PluggedNotFound;
import project.sw.machineModules.internal.consumers.Consumer;
import project.sw.machineModules.internal.containers.FlowContainer;
import project.sw.machineModules.internal.providers.Provider;
import project.sw.machineModules.external.ProductCase;
import tuc.ece.cs201.vm.hw.device.Device;
import tuc.ece.cs201.vm.hw.device.ProcessorDevice;
import tuc.ece.cs201.vm.hw.device.ProductCaseDevice;

public class IngredientProcessor extends FlowContainer implements Processor, Provider{
	
	ArrayList<Ingredient> ingredients;
	
	public IngredientProcessor(ProcessorDevice processor, int capacity) {
		super(processor, capacity, null);
		ingredients = new ArrayList<>();
	}

	public void load(Consumable con) throws ExcessiveAmountException{	
		if (this.getCapacity()<con.getQuantity()){
			throw new ExcessiveAmountException("The Consumable's Quantity has exceeded "+this.getName()+"\'s Capacity");
		}
		this.ingredients.add((Ingredient)con);
		System.out.println(con.getName()+" was loaded");
	}

	public boolean accepts(Consumable con) {
		try {
			return (Class.forName("project.consumables.Ingredient").isInstance(con));
		} catch (ClassNotFoundException e) {
			System.out.println("Class "+con.getClass()+" not Found");
			return false;
		}
	}

	public void process(int duration) throws ClosedDeviceException{
		
		GraphicProcessor gProcessor = (GraphicProcessor)SwingVM.getInstance().getDevice(this.getName());
		
		//this.device.close();
		gProcessor.open();
		if(/*this.device.isOpen()*/!gProcessor.isOpen()) {
			throw new ClosedDeviceException(this.device.getName()+" is still open");
		}
		//((ProcessorDevice)this.device).operateStart();
		gProcessor.operateStart();
		this.wait(duration);
		ProcessedIngredient content = new ProcessedIngredient(((ProcessorDevice)this.device).getProcessingLabel());
		for (Consumable ing : ingredients) {
			content.addIngredient((Ingredient) ing);
		}
		ingredients.clear();
		ingredients.add(content);
		this.content = content;
		//((ProcessorDevice)this.device).operateStop();
		gProcessor.operateStop();
		//this.device.open();
		gProcessor.close();
	}
	
	public void provide(Consumer confRef, int quantity) throws IncompatibilityException, LowQuantityException, PluggedNotFound, ExcessiveAmountException{ 	//add quantity exception, incompatible exception
		
		ProcessorDevice gProcessor = (ProcessorDevice)SwingVM.getInstance().getDevice(this.getName());
		Device gConsumer;
		
		this.plug(confRef);
		if(!confRef.accepts(content)) {
			throw new IncompatibilityException(this.getContent().getName()+" is incompatible with "+confRef.toString()+" Consumer.");
		}
		if (quantity>this.content.getQuantity()) {
			throw new LowQuantityException("The Quantity of "+this.getContent().getName()+" is less than needed.");
		}
		for(int i=0; i<quantity; i+=/*((ProcessorDevice)this.device).streamRate()*/gProcessor.streamRate()) {
			try {
				if (Class.forName("project.sw.dispenserModules.internal.processor.IngredientProcessor").isInstance(confRef)) {
					//((ProcessorDevice)this.device).streamOut(((IngredientProcessor)confRef).getDevice());
					gProcessor.streamOut(((IngredientProcessor)confRef).getDevice());
				}else if (Class.forName("project.sw.machineModules.external.ProductCase").isInstance(confRef)) {
					//((ProcessorDevice)this.device).streamOut(((ProductCase)confRef).getDevice());
					gProcessor.streamOut(((ProductCase)confRef).getDevice());
				}
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
			try {
				if (Class.forName("project.sw.dispenserModules.internal.processor.IngredientProcessor").isInstance(confRef)) {
					//((ProcessorDevice)((IngredientProcessor)confRef).getDevice()).streamIn();
					gConsumer = (ProcessorDevice)SwingVM.getInstance().getDevice(((IngredientProcessor)confRef).getName());
					((ProcessorDevice)gConsumer).open();
					((ProcessorDevice)gConsumer).streamIn();
				}
				else if (Class.forName("project.sw.machineModules.external.ProductCase").isInstance(confRef)) {
					//((ProductCaseDevice)((ProductCase)confRef).getDevice()).loadIngredient(this.content.getName());
					gConsumer = (ProductCaseDevice)SwingVM.getInstance().getDevice(((ProductCase)confRef).getName());
					((ProductCaseDevice)gConsumer).unLock();
					((ProductCaseDevice)gConsumer).loadIngredient(this.content.getName());
				}
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}			
			this.wait(1);
		}
		try {
			if (Class.forName("project.sw.dispenserModules.internal.processor.IngredientProcessor").isInstance(confRef)) {
				gConsumer = (ProcessorDevice)SwingVM.getInstance().getDevice(((IngredientProcessor)confRef).getName());
				((ProcessorDevice)gConsumer).close();
			}
			else if (Class.forName("project.sw.machineModules.external.ProductCase").isInstance(confRef)) {
				gConsumer = (ProductCaseDevice)SwingVM.getInstance().getDevice(((ProductCase)confRef).getName());
				((ProductCaseDevice)gConsumer).lock();
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		gProcessor.close();
		confRef.load(this.content.getPart(quantity));
		this.ingredients.clear();
		this.unPlug(confRef);
	}

	public void provide(Consumer confRef) throws IncompatibilityException, PluggedNotFound, ExcessiveAmountException {
		
		GraphicProcessor gProcessor = (GraphicProcessor)SwingVM.getInstance().getDevice(this.getName());
		Device gConsumer;
		
		this.plug(confRef);
		if(!confRef.accepts(content)) {
			throw new IncompatibilityException(this.getContent().getName()+" is incompatible with "+confRef.toString()+" Consumer.");
		}
		gProcessor.open();
		for(int i=0; i<content.getQuantity(); i+=/*((ProcessorDevice)this.device).streamRate()*/gProcessor.streamRate()) {
			try {
				if (Class.forName("project.sw.dispenserModules.internal.processor.IngredientProcessor").isInstance(confRef)) {
					//((ProcessorDevice)this.device).streamOut(((IngredientProcessor)confRef).getDevice());
					gProcessor.streamOut(((IngredientProcessor)confRef).getDevice());
				}else if (Class.forName("project.sw.machineModules.external.ProductCase").isInstance(confRef)) {
					//((ProcessorDevice)this.device).streamOut(((ProductCase)confRef).getDevice());
					gProcessor.streamOut(((ProductCase)confRef).getDevice());
				}
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
			try {
				if (Class.forName("project.sw.dispenserModules.internal.processor.IngredientProcessor").isInstance(confRef)) {
					//((ProcessorDevice)((IngredientProcessor)confRef).getDevice()).streamIn();
					gConsumer = (ProcessorDevice)SwingVM.getInstance().getDevice(((IngredientProcessor)confRef).getName());
					((ProcessorDevice)gConsumer).open();
					((ProcessorDevice)gConsumer).streamIn();
				}
				else if (Class.forName("project.sw.machineModules.external.ProductCase").isInstance(confRef)) {
					//((ProductCaseDevice)((ProductCase)confRef).getDevice()).loadIngredient(this.content.getName());
					gConsumer = (ProductCaseDevice)SwingVM.getInstance().getDevice(((ProductCase)confRef).getName());
					((ProductCaseDevice)gConsumer).unLock();
					((ProductCaseDevice)gConsumer).loadIngredient(this.content.getName());
				}
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}			
			this.wait(1);
		}
		try {
			if (Class.forName("project.sw.dispenserModules.internal.processor.IngredientProcessor").isInstance(confRef)) {
				gConsumer = (ProcessorDevice)SwingVM.getInstance().getDevice(((IngredientProcessor)confRef).getName());
				((ProcessorDevice)gConsumer).close();
			}
			else if (Class.forName("project.sw.machineModules.external.ProductCase").isInstance(confRef)) {
				gConsumer = (ProductCaseDevice)SwingVM.getInstance().getDevice(((ProductCase)confRef).getName());
				((ProductCaseDevice)gConsumer).lock();
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		gProcessor.close();
		confRef.load(this.content);
		this.ingredients.clear();
		this.unPlug(confRef);
	}

	public void wait(int time) {
		try {
			Thread.sleep(time*1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}
