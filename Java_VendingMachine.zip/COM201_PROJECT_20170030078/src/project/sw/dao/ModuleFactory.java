package project.sw.dao;

import project.consumables.*;
import project.hw.hardwareMachine.*;
import project.sw.dispenserModules.internal.processor.IngredientProcessor;
import project.sw.machineModules.external.*;
import project.sw.machineModules.internal.containers.*;
import project.sw.machineModules.internal.dispensers.ConsumableDispenser;
import project.sw.vendingMachine.Module;

public class ModuleFactory {
	
	public static Module<?> createModule(tuc.ece.cs201.vm.hw.device.Device dev) {
		Module<?> m=null;
		
		switch (dev.getType()) {
		case NumPad:
			m = new NumPad((NumPadDevice) dev);
			break;
		case ChangeCase:
			m = new ChangeCase((ChangeCaseDevice) dev);
			break;
		case CoinReader:
			m = new CoinReader((CoinAcceptorDevice) dev);
			break;
		case Display:
			m = new DisplayPanel((DisplayDevice) dev);
			break;
		case ProductCase:
			m = new ProductCase((ProductCaseDevice) dev);
			break;
		case DosingContainer:
			m = new DosingContainer((DosingContainerDevice) dev, ((DosingContainerDevice) dev).getCapacity(), new Powder(dev.getName(), ((DosingContainerDevice) dev).getCapacity()));
			break;
		case FlowContainer:
			m = new FlowContainer((FlowContainerDevice) dev, ((FlowContainerDevice) dev).getCapacity(), new Liquid(dev.getName(), ((FlowContainerDevice) dev).getCapacity()));
			break;
		case MaterialContainer:
			if(dev.getName().equalsIgnoreCase("big_cup"))
				m = new MaterialContainer((MaterialContainerDevice) dev, 30, new Cup(dev.getName(), 30, "Grande"));
			if(dev.getName().equalsIgnoreCase("small_cup"))
				m = new MaterialContainer((MaterialContainerDevice) dev, 30, new Cup(dev.getName(), 30, "Regular"));
			break;
		case DosingDispenser:
			m = new ConsumableDispenser((DispenserDevice<DosingContainerDevice>) dev);
			break;
		case FlowDispenser:
			m = new ConsumableDispenser((DispenserDevice<FlowContainerDevice>) dev);
			break;
		case MaterialDispenser:
			m = new ConsumableDispenser((DispenserDevice<FlowContainerDevice>) dev);
			break;
		case Processor:
			m = new IngredientProcessor((ProcessorDevice) dev, 200);
			break;
		default:
			break;
		
		}
		System.out.println(dev.getName()+" Module Created");
		return m;
	
	}
}
