package project.sw.dao;

import java.util.List;

import project.sw.recipe.Recipe;

public interface RecipeDAO {
    List<Recipe> loadRecipes();
    boolean storeRecipe(Recipe recipe);
    boolean deleteRecipe(int code);
}
