package project.consumables;

public class Powder extends Ingredient{
	
	public Powder(String name, int quantity) {
		super(name,quantity);
	}
}
