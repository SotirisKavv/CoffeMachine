package project.consumables;

import java.util.*;


public class ProcessedIngredient extends Ingredient{
	
	private List<Ingredient> ingredients;
	
	public ProcessedIngredient(String name) {
		super(name, 0);
		ingredients = new ArrayList<Ingredient>();
	}
	
	public String getName() {
		String ing="";
		
		for (int i=0; i<ingredients.size(); i++) {
			ing+=(ingredients.get(i).getName()+",");
		}
		ing=ing.substring(0, ing.length()-1);
		
		return this.name+"("+ing+")";
	}
	
	public void resetIngredients() {
		ingredients = new ArrayList<>(); 
	}
	
	public void addIngredient(Ingredient i) {
		ingredients.add(i);
		this.setQuantity(this.getQuantity()+i.getQuantity());
	}
	
	public ProcessedIngredient clone() throws CloneNotSupportedException {
		ProcessedIngredient clone = (ProcessedIngredient) super.clone();
		clone.resetIngredients();
		for (Ingredient ig : ingredients)
			clone.addIngredient((Ingredient)ig.clone());
		return clone;
	}
	
}
