package project.consumables;

public class Cup extends Material{
	
	protected String size;
	
	public Cup(String name, int quantity, String size) {
		super(name,quantity);
		this.size = size;
	}
	
	public String getSize() {
		return size;
	}

	public void setSize(String size) {
		this.size = size;
	}
}
