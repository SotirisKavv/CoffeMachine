package project.productBuilder;

import project.consumables.Consumable;

public abstract class ProductBuilder {
	
	protected Product product;
	
	public static ProductBuilder getProductBuilder(String type) throws IllegalAccessException {
        if (type.equalsIgnoreCase("defaultDrink")){
            return new DefaultDrinkBuilder();
        }else{
            throw new IllegalAccessException("Unknown Builder Type");
        }
    }
	
	public ProductBuilder setCost(int cost) {
		product.setCost(cost);
		return this;
	}
	
	public ProductBuilder setName(String name) {
		product.setName(name);
		return this;
	}
	
	public Product getProduct() {
		return product;
	}
	
	public abstract void addConsumable(Consumable con);
}
