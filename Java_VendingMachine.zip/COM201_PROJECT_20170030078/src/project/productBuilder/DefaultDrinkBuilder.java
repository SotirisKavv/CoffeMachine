package project.productBuilder;

import project.consumables.Consumable;

public class DefaultDrinkBuilder extends ProductBuilder{

	public DefaultDrinkBuilder() {
		this.product = new Product();
	}
	
	public void addConsumable(Consumable con)  {
		if(this.getProduct().getContent().size()==0) {
			try {
				if(Class.forName("project.consumables.Material").isInstance(con))
					this.getProduct().addConsumable(con);
			} catch (ClassNotFoundException e) {
				System.out.println("Can't place "+con.getName()+" now!");
			}
		} else if (this.getProduct().getContent().size()==1){
			try {
				if(Class.forName("project.consumables.Ingredient").isInstance(con))
					this.getProduct().addConsumable(con);
			} catch (ClassNotFoundException e) {
				System.out.println("Can't place "+con.getName()+" now!");
			}
		}
	}
}
