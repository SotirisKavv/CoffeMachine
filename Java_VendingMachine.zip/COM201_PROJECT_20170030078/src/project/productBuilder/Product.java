package project.productBuilder;

import java.util.ArrayList;
import java.util.List;

import project.consumables.*;

public class Product {
	
	private List<Consumable> consumables;
	private int cost;
	private String name;
	
	public Product() {
		consumables= new ArrayList<>();
	}
	
	public void addConsumable(Consumable con) {
		this.consumables.add(con);
	}
	
	public List<Consumable> getContent(){
		return this.consumables;
	}

	public int getCost() {
		return cost;
	}

	public void setCost(int cost) {
		this.cost = cost;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	
}
